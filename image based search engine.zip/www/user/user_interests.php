<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	$current_user	=	$_SESSION['current_login_user'];
	
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/signin.php");
	}
	
	$update_success	=	0;
	
	$interests	=	"";
	$image_type	=	"";
	$image_color=	"";
	$image_resol=	"";
	
	if(isset($_POST['form_submit_btn']))
	{
		$interests	=	$_POST['keyword'];
		$image_type	=	$_POST['img_type'];
		$image_color=	$_POST['img_color'];
		$image_resol=	$_POST['img_size'];
		
		$check_record_exist	=	$db->check_interest_exist($current_user);
		
		if($check_record_exist=="")
		{
			if($image_type=="Any Image type")
			{
				$image_type	=	"";
			}
			if($image_color=="Any Image color")
			{
				$image_color	=	"";
			}
			if($image_resol=="All Resolution Images")
			{
				$image_resol	=	"";
			}
			
			//save
			$db->save_user_interest($current_user,$interests,$image_type,$image_color,$image_resol);
			$update_success	=	1;
		}
		else
		{
			if($image_type=="Any Image type")
			{
				$image_type	=	"";
			}
			if($image_color=="Any Image color")
			{
				$image_color	=	"";
			}
			if($image_resol=="All Resolution Images")
			{
				$image_resol	=	"";
			}
			
			//update
			$db->update_user_interests($current_user,$interests,$image_type,$image_color,$image_resol);
			$update_success	=	1;
		}
	}
	
	$user_interest_data	=	array();
	$user_interest_data	=	$db->get_user_interest($current_user);
	
	if(!empty($user_interest_data))
	{
		$interests	=	$user_interest_data[2];
		$image_type	=	$user_interest_data[3];
		$image_color=	$user_interest_data[4];
		$image_resol=	$user_interest_data[5];
	}
?>

<html>
<head>
	<title>My Interests</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>


<?php 
	require_once('../header.php');
?>

<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	<?php
		require_once('user_menus.php');
	?>

	<div class="page_head_titles">My Interests</div>

	<div class="form_container">
		<?php
			if($update_success==1)
			{
		?>
			<div class="success_msg">Your Interest Updated Successfully!</div>
		<?php
			}
		?>
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
			
			<textarea name="keyword" class="form_txtbx" placeholder="Enter your Interests separated by comma" required><?php echo $interests; ?></textarea>
			<select name="img_type" class="form_txtbx">
				<?php
					if($image_type!="")
					{
				?>
				<option value="<?php echo $image_type; ?>"><?php echo $image_type; ?></option>
				<?php
					}
				?>
				<option value="Any Image type">Any Image type</option>
				<option value="face">face</option>
				<option value="clip art">clip art</option>
				<option value="photo">photo</option>
				<option value="line drawing">line drawing</option>
				<option value="animated">animated</option>
				</select>
			
			<select name="img_color" class="form_txtbx">
				<?php
					if($image_color!="")
					{
				?>
				<option value="<?php echo $image_color; ?>"><?php echo $image_color; ?></option>
				<?php
					}
				?>
				<option value="Any Image color">Any Image color</option>
				<option value="black and white">black and white</option>
				<option value="transparent">transparent</option>
				

			</select>
			
			<select name="img_size" class="form_txtbx">
				<?php
					if($image_resol!="")
					{
				?>
				<option value="<?php echo $image_resol; ?>"><?php echo $image_resol; ?></option>
				<?php
					}
				?>
				<option value="All Resolution Images">All Resolution Images</option>
				<option value="400-300">400-300</option>
				<option value="640-480">640-480</option>
				<option value="800-600">800-600</option>
				<option value="1024-768">1024-768</option>
				<option value="2MP(1600-1200)">2MP(1600-1200)</option>
				<option value="4MP(2272-1704)">4MP(2272-1704)</option>
				<option value="6MP(2816-2112)">6MP(2816-2112)</option>
				<option value="8MP(3264-2448)">8MP(3264-2448)</option>
				<option value="10MP(3648-2736)">10MP(3648-2736)</option>
				<option value="12MP(4096-3072)">12MP(4096-3072)</option>
				<option value="15MP(4480-3360)">15MP(4480-3360)</option>
				<option value="20MP(5120-3840)">20MP(5120-3840)</option>
				<option value="40MP(7216-5412)">40MP(7216-5412)</option>
				<option value="70MP(9600-7200)">70MP(9600-7200)</option>
				


			</select>
			
			
			<br /><br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Update"/>
		</form>
	</div>
</div>

<?php
	require_once('../footer.php');
?>


</body>
</html>