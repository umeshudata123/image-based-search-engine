<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	$image_error = "";
	$flag = 0;
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/signin.php");
	}
	$users_session_email	=	$_SESSION['current_login_user'];
	$current_login_user_id = 	$db->fetch_users_id_by_email($users_session_email);
	
	if(isset($_POST['submit_btn']))
	{
		$valid_formats = array("jpg", "png", "gif", "bmp","JPEG","JPG","BMP","PNG");
	
		if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name 				= 	$_FILES['photoimg']['name'];
			$size 				= 	$_FILES['photoimg']['size'];
		
				if(strlen($name))
				{
					
					list($txt, $ext) = explode(".", $name);
					
					if(in_array($ext,$valid_formats))
					{
						$files	=	array();

						function generateRandomString($length = 10) {
							$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
							$charactersLength = strlen($characters);
							$randomString = '';
							for ($i = 0; $i < $length; $i++) 
							{
								$randomString .= $characters[rand(0, $charactersLength - 1)];
							}
							return $randomString;
						}
						
						$current_random_string = generateRandomString();
						
						$actual_image_name = $current_random_string.".".strtolower($ext);
		
						//Update image name for profile picture
						
						$tmp = $_FILES['photoimg']['tmp_name'];
						
						$img_Dir = 'profile/';
						
						if (!file_exists($img_Dir)) 
						{
							mkdir($img_Dir);
						}
						
						if(move_uploaded_file($tmp,$img_Dir.$actual_image_name))
						{
							
						}
						else
						{
							$image_error = "Invalid File Formate";
						}
					}
					else
					{
						$image_error = "Invalid File Formate";
						$flag = 1;
					}	
				}
			else
			{
				$image_error = "Invalid File Formate";
			}
		}
		if($flag == 0)
		{
			$db->update_profile_image_by_id($current_login_user_id,$actual_image_name);
		}
	}
	if(isset($_GET['remove_prof_id']) AND isset($_GET['image']))
	{
		$delete_id	=	$_GET['remove_prof_id'];
		$image		=	$_GET['image'];
		unlink("profile/".$image);
		$db->delete_profile_image($delete_id);
		header("Location:profile.php");
	}
?>
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	<?php
	require_once("../header.php");
	?>
	<style>
	.img-icon
	{
		width:180px;
		padding:5px;
		height:180px;
		border:1px solid #DFDFDF;
		box-shadow:0px 0px 3px 0px #DFDFDF;
	}
	.remove_prof_pic
	{
		text-decoration:none;
		margin-top:-39px;
		display:inline-table;
		background-color:#333;
		width:165px;
		padding:7px;
		color:#FFF;
		opacity:0.8;
	}
	</style>
	<div id="middle_section" style="background-image:url('/images/back1.jpg'); background-size:100% 100%;">
	
	<?php
		require_once('user_menus.php');
	?>
		<br />
		<center class="txt_dspl">Profile Image</center>
		<br />
		<div style="border:0px solid;width:250px;margin:auto;padding:5px;text-align:center;">
		<form action="" method="post" enctype="multipart/form-data">
		<?php
			$profile_image	=	$db->get_user_profile_image($users_session_email);
			
			if($profile_image != "")
			{
		?>
			<img src="profile/<?php echo $profile_image; ?>" class="img-icon" /><br />
			
			<a href="profile.php?remove_prof_id=<?php echo $current_login_user_id; ?>&image=<?php echo $profile_image; ?>" class="remove_prof_pic">Remove Picture</a>
		<?php
			}
			else
			{
		?>
			<img src="/images/user-icon-new.png" class="img-icon" />
		<?php	
			}
		?>			
			
			<input type="file" name="photoimg" id="prof_image_uploader" class="upload-image" /><br /><br />
			<span style="color:red;"><?php echo $image_error; ?></span><br />
			<input type="submit" name="submit_btn" class="form_submit_btn" value="Upload Image" />
			
			
		</form>
		</div>
	</div>
</body>
<?php
	require_once("../footer.php");
?>
