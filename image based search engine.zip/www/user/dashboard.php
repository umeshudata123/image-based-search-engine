<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/signin.php");
	}
	
	$users_session_email	=	$_SESSION['current_login_user'];
?>
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	<?php
	require_once("../header.php");
	?>
	<div id="middle_section" style="background-image:url('/images/back1.jpg'); background-size:100% 100%;">
	
	<?php
		require_once('user_menus.php');
		
		$current_user_interest	=	$db->get_all_current_user_interests($users_session_email);
		
		$search_query	=	$current_user_interest[0][0]." ".$current_user_interest[0][1]." ".$current_user_interest[0][2]." ".$current_user_interest[0][3];
		
		$searched_images_data	=	array();
			
		$searched_images_data	=	$db->get_all_searched_images($search_query);
			
			if(!empty($searched_images_data))
			{
	?>
		<br />
		<center class="txt_dspl">We Thought The Following Images Matches With Your Interests.</center>
		<br />
	<?php
				$count = 0;
				foreach($searched_images_data as $record)
				{
					$cur_id	=	$record;
					$count = 0;
					
					$d_data	=	array();
					$d_data	=	$db->get_current_d_data($cur_id);
					
					$res_id			=	$d_data[$count][0];
					$res_image_name	=	$d_data[$count][1];
					$res_colours	=	$d_data[$count][2];
					$res_description=	$d_data[$count][3];
					$res_image_type	=	$d_data[$count][4];
					$res_keywords	=	$d_data[$count][5];
					$res_posted_by	=	$d_data[$count][6];
					$res_date		=	$d_data[$count][7];
					$res_time		=	$d_data[$count][8];
					$res_status		=	$d_data[$count][9];
			?>
				<div class="img_display_thumb" style="display:inline-table;">
					<a href="/gallery/<?php echo $res_image_name; ?>" target="_blank"><img src="/gallery/<?php echo $res_image_name; ?>" class="img_thumb" /></a>
				</div>
		
			<?php
					$count++;
				}
			}
			else
			{
		?>
		<br />
		<center class="txt_dspl">No Search Results Found</center>
		<br />
<?php		
			}
	?>
		
	</div>
</body>
<?php
	require_once("../footer.php");
?>
