<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	require_once('../ColorDetection.php');

	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/signin.php");
	}
	
		$block_flag	=	0;
		
		$current_login_user	=	$_SESSION['current_login_user'];
	
		if(isset($_POST['form_submit_btn']))
		{
		
		$valid_formats = array("jpg", "png", "gif", "bmp","JPEG","JPG","BMP","PNG");
	
		if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name 				= 	$_FILES['photoimg']['name'];
			$size 				= 	$_FILES['photoimg']['size'];
			$colours			=	$_POST['colours'];
			$description		=	$_POST['description'];
			$keywords			=	$_POST['image_keywords'];
			$type				=	$_POST['image_type'];
			
		
				if(strlen($name))
				{
					
					list($txt, $ext) = explode(".", $name);
					
					if(in_array($ext,$valid_formats))
					{
						$files	=	array();

						function generateRandomString($length = 10) {
							$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
							$charactersLength = strlen($characters);
							$randomString = '';
							for ($i = 0; $i < $length; $i++) 
							{
								$randomString .= $characters[rand(0, $charactersLength - 1)];
							}
							return $randomString;
						}
						
						$current_random_string = generateRandomString();
						
						$actual_image_name = date("Y-m-d").$current_random_string.".".strtolower($ext);
				
						$spam_images = $db->get_all_spam_images();
						$count = 0;
						$tmp = $_FILES['photoimg']['tmp_name'];	
						
						if(!empty($spam_images))
						{
							foreach($spam_images as $record)
							{
								$id = $spam_images[$count][0];
								$img_name	=	$spam_images[$count][1];
								
								$image1 = $tmp;
								$image2 = "../blocked-images/".$img_name;
								
								$md5image1 = md5(file_get_contents($image1));
								$md5image2 = md5(file_get_contents($image2));
								
								if($md5image1 == $md5image2)
								{
									$block_flag		=	1;
								}
								$count++;
							}
						}	
						
						if($block_flag==0)
						{
							
							$colorDetection = new ColorDetection();

							$imageColors = $colorDetection->detectColors($tmp);
							//var_dump($imageColors);
							
							  $red		=	$imageColors['red'];
							  $orange	=	$imageColors['orange'];
							  $yellow	=	$imageColors['yellow'];
							  $green	=	$imageColors['green'];
							  $turquoise=	$imageColors['turquoise'];
							  $blue		=	$imageColors['blue'];
							  $purple	=	$imageColors['purple'];
							  $pink		=	$imageColors['pink'];
							  $white	=	$imageColors['white'];
							  $gray		=	$imageColors['gray'];
							  $black	=	$imageColors['black'];
							  $brown	=	$imageColors['brown'];
							
							$db->save_my_uploaded_file($actual_image_name,$colours,$description,$keywords,$type,$current_login_user,$red,$orange,$yellow,$green,$turquoise,$blue,$purple,$pink,$white,$gray,$black,$brown);
							
							$tmp = $_FILES['photoimg']['tmp_name'];
							
							$img_Dir = "../gallery/";
							
							if (!file_exists($img_Dir)) {
								mkdir($img_Dir);
							}
							
							if(move_uploaded_file($tmp, $img_Dir.$actual_image_name))
							{
							}
							else
							{
								echo "alert('failed');";
							}
						}
					}
					else
					{
						echo "alert('Invalid file format..')";	
					}	
				}
			else
			{
				echo "alert('Please select image..!')";
			}
		}
	}	
?>
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	<?php
	require_once("../header.php");
	?>
	<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	
	<?php
		require_once('user_menus.php');
	?>
	<div class="page_head_titles">My Image Gallery</div>
		
		<div class="form_container" style="width:auto;">
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
			
			<?php
				if($block_flag==1)
				{
			?>
			<div class="alert_msgs">This image is blocked for security reason.So, You can't post this image.</div>
			<?php
				}
			?>			
			
			<input type="file" name="photoimg" id="prof_image_uploader" class="upload-image" />
		<br />
			
			<input type="text" name="colours" class="form_txtbx" placeholder="Enter colours of image" />
			<input type="text" name="image_type" class="form_txtbx" placeholder="Enter image type" />
			<textarea name="description" class="form_txtbx" placeholder="Enter description for image"></textarea>
			
			<textarea name="image_keywords" class="form_txtbx" placeholder="Enter keywords for image"></textarea>
			
			<br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Update"/>
		</form>
	
	</div>
	
	
	<div class="my_image_container">
	
		<?php
			$del_flag	=	0;
			if(isset($_GET['del_id']) AND isset($_GET['img']))
			{	
				$delete_id	=	$_GET['del_id'];
				$image_name	=	$_GET['img'];
				
				if($image_name!="")
				{
					unlink('../gallery/'.$image_name);
				}
				
				if($db->delete_current_image($delete_id))
				{
					$del_flag	=	1;
				}
			}
			
			if($del_flag==1)
			{
		?>
			<div class="success_msg"><?php echo $image_name; ?> - Image deleted successfully</div>
		<?php
			}
			
			
			$my_images	=	array();
			
			$my_images	=	$db->get_all_my_uploaded_images($current_login_user);
			
			if(!empty($my_images))
			{
				$counter	=	0;
				
				foreach($my_images as $image)
				{	
					$res_id			=	$my_images[$counter][0];
					$res_image_name	=	$my_images[$counter][1];
					$res_colours	=	$my_images[$counter][2];
					$res_description=	$my_images[$counter][3];
					$res_image_type	=	$my_images[$counter][4];
					$res_keywords	=	$my_images[$counter][5];
					$res_posted_by	=	$my_images[$counter][6];
					$res_date		=	$my_images[$counter][7];
					$res_time		=	$my_images[$counter][8];
					$res_status		=	$my_images[$counter][9];
		?>
			<div class="img_display_thumb" style="display:inline-table;">
			<a href="/gallery/<?php echo $res_image_name; ?>" target="_blank"><img src="/gallery/<?php echo $res_image_name; ?>" class="img_thumb" /></a><br />
			<a href="<?php echo $_SERVER['PHP_SELF']."?del_id=".$res_id."&img=".$res_image_name; ?>" class="link">Delete</a>
			<?php
				if($res_status=="Approved")
				{
			?>
			<label style="color:Green">
			(<?php echo $res_status; ?>)
			</label>
			<?php
				}
				else
				{
			?>
			<label style="color:RED">
			(<?php echo $res_status; ?>)
			</label>
			<?php
				}
			?>
			</div>
		<?php
					$counter++;
				}
			}
		?>
		
	</div>
	
	</div>
</body>
<?php
	require_once("../footer.php");
?>
