<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	$users_session_id	=	$_SESSION['current_login_user'];
	
	$contact_num_error	=	"";
	$password_error		=	"";
	$conf_pwd_error		=	"";
	$flag 				=	0;
	$success_flag		=	0;
	
	$username	=	"";
	$contact_num=	"";
	$email_id	=	"";
	$dob		=	"";
	$gender		=	"";
	$password	=	"";
	$result		=	"";
	$users_data	=	array();
	
	$users_data	=	$db->fetch_data($users_session_id);
	
	if(!empty($users_data))
	{
		$username	=	$users_data[1];
		$contact_num=	$users_data[2];
		$email_id	=	$users_data[3];
		$dob		=	$users_data[4];
		$gender		=	$users_data[5];
	}
	if(isset($_POST['form_submit_btn']))
	{
		$username	=	$_POST['username'];
		$contact_num=	$_POST['contact_num'];
		$email_id	=	$_POST['user_email'];
		$dob		=	$_POST['user_dob'];
		$gender		=	$_POST['user_gender'];
		
		if($db->update_user_data($username,$contact_num,$users_session_id,$dob,$gender))
		{
			$result="Updation Successful";
		}
		else
		{
			$result="Updation Failed";
		}
	}
	
		
?>


<html>
<head>
	<title>My Profile</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>


<?php 
	require_once('../header.php');
?>

<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	<?php
		require_once('user_menus.php');
	?>

	<div class="page_head_titles">My Profile</div>
	
	<div class="form_container">
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
			
			<span class="error_indicator"><?php echo $result;?></span>
		
			<input type="text" name="username" class="form_txtbx" placeholder="Enter full name" required value="<?php echo $username; ?>"  />
			<input type="text" name="contact_num" class="form_txtbx" placeholder="Enter contact number" required  value="<?php echo $contact_num; ?>" />
			<span class="error_indicator"><?php echo $contact_num_error; ?></span>
			<input type="email" name="user_email" class="form_txtbx" placeholder="Enter email id" required  value="<?php echo $email_id; ?>" readonly />
			<input type="text" name="user_dob" class="form_txtbx" placeholder="Enter date of birth" required  value="<?php echo $dob; ?>" />
			<select name="user_gender" class="form_txtbx">
				<?php
					if($gender!="")
					{
				?>
				<option value="<?php echo $gender; ?>"><?php echo $gender; ?></option>
				<?php
					}
				?>
				<option value="Select Gender">Select Gender</option>
				<option value="Male">Male</option>
				<option value="Female">Female</option>
			</select>
			
			<br /><br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Update"/>
		</form>
	</div>
</div>

<?php
	require_once('../footer.php');
?>


</body>
</html>