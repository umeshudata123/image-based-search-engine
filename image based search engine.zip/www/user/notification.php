<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/signin.php");
	}
	$users_session_email	=	$_SESSION['current_login_user'];
?>
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	<?php
	require_once("../header.php");
	?>
	<div id="middle_section" style="background-image:url('/images/back1.jpg'); background-size:100% 100%;">
	
	<?php
		require_once('user_menus.php');
		
		
	?>
		<br />
		<center class="txt_dspl">Deleted Images</center>
		<br />
	<?php
		$d_data	=	$db->get_deleted_image_by_admin($users_session_email);	
			if(!empty($d_data))
			{
				$count = 0;
				foreach($d_data as $record)
				{
					$res_id			=	$d_data[$count][0];
					$res_image_name	=	$d_data[$count][1];
					
			?>
				<div class="img_display_thumb" style="display:inline-table;">
					<a href="/gallery/<?php echo $res_image_name; ?>" target="_blank"><img src="/gallery/<?php echo $res_image_name; ?>" class="img_thumb" /></a>
					This Image is Deleted By Admin.
				</div>
		
			<?php
					$count++;
				}
			}
			else
			{
		?>
		<br />
		<center class="txt_dspl">No Search Results Found</center>
		<br />
<?php		
			}
	?>
		
	</div>
</body>
<?php
	require_once("../footer.php");
?>
