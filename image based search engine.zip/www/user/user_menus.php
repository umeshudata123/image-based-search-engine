<?php
	require_once("../lib/functions.php");
	$db = new db_functions();	
?>
<script type="text/javascript" src="/js/jquery-1.10.2.js"></script>
<script>
	$(document).ready(function(){

		$("#img_profile").click(function(){
		$("#display-div").toggle();
		});
	});
</script>
	<div class="user_menus">
			<a href="/user/dashboard.php" class="menu">My Dashboard</a>
			<a href="user_profile.php" class="menu">Profile</a>
			<a href="user_interests.php" class="menu">Interests</a>
			<a href="/user/change_password.php" class="menu">Change Password</a>
			<a href="/user/suggetion_queries.php" class="menu">Suggetion Box</a>
			<a href="/user/my-uploads.php" class="menu">My Image Gallery</a>
			<a href="/user/notification.php" class="menu">Notification</a>
			<a href="/user/profile.php" class="menu">Profile Picture</a>
			<div class="User_name">
				<a class="menu" id="img_profile">
				<?php
					$email 		= $_SESSION['current_login_user'];
					$name  		= $db->fetch_users_name_by_email($email);
					$profile 	= $db->get_user_profile_image($email);
				?>
				<span><img src="profile/<?php echo $profile; ?>" style="border-radius:50px;height:50px;width:50px;padding:5px;border:1px solid #cdcdcd;"></span><br />
<?php
					echo $_SESSION['current_login_user'];
				?></a>
				
			</div>
			<div id="display-div" style="position:absolute;float:right;right:120px;height:120px;width:200px;border:1px solid #ccc;text-align:center;background:#fff;display:none;">
				
				<span><img src="profile/<?php echo $profile; ?>" style="border-radius:50px;height:50px;width:50px;padding:5px;border:1px solid #cdcdcd;"></span><br />

				<span style="font-weight:bold;"><?php echo $name; ?></span><br />
				<span><?php echo $email; ?></span><br />
				<a href="/signin.php?lout_c_u" >Logout</a>
			</div>
	</div>

