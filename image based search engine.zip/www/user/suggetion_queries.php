<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	$users_email_id	=	$_SESSION['current_login_user'];

	if(!isset($_SESSION['current_login_user']))
	{
		header("Location:/signin.php");
	}
	
	
			
	
	$flag	=	0;
	if(isset($_POST['form_submit_btn']))
	{
		$suggetion_message	=	$_POST['user_suggetion'];
		
		if($db->save_user_suggetion($users_email_id,$suggetion_message))
		{
			$flag	=	1;
		}
	}
	?>
<html>
<head>
	<title>Suggetion Box</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>


<?php 
	require_once('../header.php');
?>

<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	<?php
		require_once('user_menus.php');
	?>
	<div class="page_head_titles">User Suggetion Box</div>
	
	<div class="form_container">
		<?php
			if($flag==1)
			{
		?>
			<div class="success_msg">Your suggestions sent to admin! Thank You</div>
		<?php
			}
		?>
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
			
			<textarea name="user_suggetion" class="form_txtbx" placeholder="Enter your suggetion" style="height:200px;" required></textarea>

			</select>
			
			<br /><br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Submit"/>
		</form>
	</div>
	
	 	
	<div class="chat_msgs_contnr">
		<div class="mychat_title">MyChat</div>
		<br />
		<?php
		$user_suggestion_data	=	array();	
		$user_suggestion_data	=$db->show_message_list($users_email_id);
		
		if(!empty($user_suggestion_data))
		{
			$counter = 0;
			foreach($user_suggestion_data as $record)
			{
				$result_id			=	$user_suggestion_data[$counter][0];
				$result_sent_from	=	$user_suggestion_data[$counter][1];
				$result_sent_to		=	$user_suggestion_data[$counter][2];
				$result_message		=	$user_suggestion_data[$counter][3];
				$result_reply_to	=	$user_suggestion_data[$counter][4];
				$result_date		=	$user_suggestion_data[$counter][5];
				$result_time		=	$user_suggestion_data[$counter][6];
		?>	
		<div style="width:100%; display:inline-table;">	
			<div class="chat_messages" style="<?php if($result_sent_from=="admin"){ ?>float:right; background-color:MEDIUMBLUE; color:#FFFFFF; margin-top:-1px;<?php } ?>"><?php echo $result_message; ?></div>
		</div>	
		<?php
				$counter++;
				}
		}
		?>
		
	</div>
</div>

<?php
	require_once('../footer.php');
?>


</body>
</html>