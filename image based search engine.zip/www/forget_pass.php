<?php
	require_once("lib/functions.php");
	$db = new db_functions();
	
	$pass_error	=	"";
	
	if(isset($_POST['form_submit_btn']))
	{
		$userid		=	$_POST['user_email'];
		
		$db_password	=	$db->check_user_exist($userid);
		
		if($db_password!="")
		{
			 $to = $userid;
			 $subject = "Web Image Search - Password Help";
			 
			 $message = "<b>Dear $userid , <br /></b> Following are your account login details <br /> Kindly login to account using below details. <br /> USER ID - $userid <br /> Password - $db_password";
		 
			 $header = "From:contact@webimagesearch.com \r\n";
			 $header .= "MIME-Version: 1.0\r\n";
			 $header .= "Content-type: text/html\r\n";
			 
			 $retval = mail($to,$subject,$message,$header);
			 
			 if( $retval == true ) {
				echo " Password Email sent successfully...";
			 }else {
				echo "Message could not be sent...";
			 }
		}
		else
		{
			$pass_error	=	"This user is not registered with us!";
		}
		
	}
?>	
<html>
<head>
	<title>Forgot Password</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>

<?php 
	require_once('header.php');
?>

	<div class="middle_section" style="min-height:560px">
		
			
		<div class="page_head_titles">Forgot Password</div>

			<div class="form_container">
			<?php
			if($pass_error!="")
			{
			?>
			<div class="success_msg" style="background-color:#FAFAFA; color:RED;">
				<?php echo $pass_error; ?>
			</div>	
			<?php	
			}
		?>
				<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
						
			<input type="email" name="user_email" class="form_txtbx" placeholder="Enter email id" required />
			
			<br /><br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Send code via email"/>
		</form>
			</div>
		
	</div>

		

<?php
	require_once('footer.php');
?>


</body>
</html>