-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2017 at 01:34 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `web_image_search`
--
CREATE DATABASE IF NOT EXISTS `web_image_search` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `web_image_search`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` text NOT NULL,
  `password` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user_id`, `password`, `date`, `time`) VALUES
(1, 'admin@wis.com', 'password', '2016-12-24', '01:00:00:PM');

-- --------------------------------------------------------

--
-- Table structure for table `applications_users`
--

CREATE TABLE IF NOT EXISTS `applications_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` text NOT NULL,
  `contact_number` text NOT NULL,
  `email_id` text NOT NULL,
  `date_of_birth` text NOT NULL,
  `gender` text NOT NULL,
  `password` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `applications_users`
--

INSERT INTO `applications_users` (`id`, `user_name`, `contact_number`, `email_id`, `date_of_birth`, `gender`, `password`, `date`, `time`) VALUES
(41, 'aishwarya', '225454', 'aishwarya@gmail.com', '1996-7-5', 'Female', '12345', '2016-10-18', '08:38:54'),
(42, 'Shweta', '2222222222', 'shweta@gmail.com', '1995-7-9', 'Select Gender', 'shweta', '2016-12-26', '05:54:35'),
(43, 'Shrikant Kadam', '9595775120', 'shri@gmail.com', '2016-01-14', 'Male', 'password', '2017-01-15', '00:31:25 AM');

-- --------------------------------------------------------

--
-- Table structure for table `blocked_images`
--

CREATE TABLE IF NOT EXISTS `blocked_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blocked_image_name` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_name` text NOT NULL,
  `colours` text NOT NULL,
  `description` text NOT NULL,
  `image_type` text NOT NULL,
  `keywords` text NOT NULL,
  `red` int(11) NOT NULL,
  `orange` int(11) NOT NULL,
  `yellow` int(11) NOT NULL,
  `green` int(11) NOT NULL,
  `turquoise` int(11) NOT NULL,
  `blue` int(11) NOT NULL,
  `purple` int(11) NOT NULL,
  `pink` int(11) NOT NULL,
  `white` int(11) NOT NULL,
  `gray` int(11) NOT NULL,
  `black` int(11) NOT NULL,
  `brown` int(11) NOT NULL,
  `posted_by` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  `status` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `red`, `orange`, `yellow`, `green`, `turquoise`, `blue`, `purple`, `pink`, `white`, `gray`, `black`, `brown`, `posted_by`, `date`, `time`, `status`) VALUES
(1, '2017-04-12yvlBl2mDXC.jpg', 'yellow car', 'sport car,road with on yellow car', '', 'audi r8,r8,yellow colour ,costly car ,sport car', 0, 6, 11, 3, 0, 0, 0, 0, 0, 23, 17, 40, 'admin@wis.com', '2017-04-12', '07:54:28 AM', 'Approved'),
(2, '2017-04-125y6KNXjtiH.jpg', 'brown audi', 'car ,four wheeler', '', 'audi r8,brown colour,classy look ,shiny colour', 0, 3, 0, 0, 0, 0, 0, 3, 20, 31, 23, 20, 'admin@wis.com', '2017-04-12', '07:55:57 AM', 'Approved'),
(3, '2017-04-12CU6UgT88XL.jpg', 'black blue shade', 'car,', '', 'audi ,r8,brown colour car,costly,black', 0, 0, 0, 0, 0, 6, 0, 0, 6, 57, 31, 0, 'admin@wis.com', '2017-04-12', '07:58:00 AM', 'Approved'),
(4, '2017-04-12UvUolAP5Wu.jpg', 'white colour', 'car ,four wheeler', '', 'audi r8, r8, audi,white pure,sports car', 0, 0, 0, 0, 0, 3, 0, 0, 6, 69, 23, 0, 'admin@wis.com', '2017-04-12', '07:59:15 AM', 'Approved'),
(12, '2017-04-127d6A6q1NgR.png', 'red car,reddish', 'red car', '', 'audi r8 ,red ,lovely car,brand new ,2 wheeler', 17, 0, 0, 2, 0, 0, 2, 0, 33, 6, 38, 2, 'admin@wis.com', '2017-04-12', '08:44:07 AM', 'Approved'),
(13, '2017-04-12wx5yo6K5Uz.jpg', 'green ,yellow green', 'lamborghini car ,sports car', '', 'Italian brand,lamborghini,green car ,sports car,lamborghini gallardo superleggera, luxury sports cars', 0, 0, 0, 59, 0, 0, 0, 0, 3, 3, 22, 13, 'admin@wis.com', '2017-04-12', '09:00:02 AM', 'Approved'),
(14, '2017-04-12f1qGVSaa2c.jpg', 'yellow sports car', 'car ', '', 'Italian brand,lamborghini,car ,sports car,yellow \r\n', 0, 11, 0, 0, 0, 0, 0, 0, 3, 3, 66, 17, 'admin@wis.com', '2017-04-12', '09:01:29 AM', 'Approved'),
(15, '2017-04-12Et455sX8bt.jpg', 'blue car', ' Volkswagen Ameo,blue car', '', 'compact sedan , Volkswagen ,Ameo,blue car', 0, 0, 0, 3, 8, 18, 0, 0, 28, 15, 30, 0, 'admin@wis.com', '2017-04-12', '09:11:47 AM', 'Approved'),
(16, '2017-04-12AxJn397rdb.jpg', 'silver', 'innova crysta,silver colour,car', '', 'innova crysta,silver colour,car,four wheeler', 0, 0, 0, 9, 0, 6, 3, 0, 6, 43, 31, 3, 'admin@wis.com', '2017-04-12', '09:14:20 AM', 'Approved'),
(17, '2017-04-12qB5BwPwg3P.jpg', 'metallic colour car', 'car ', '', 'innova crysta,metallic body ,car', 0, 0, 0, 3, 0, 13, 8, 3, 3, 10, 53, 10, 'admin@wis.com', '2017-04-12', '09:16:05 AM', 'Approved'),
(18, '2017-04-127pOZdo1qnY.jpg', 'green ,white ,blue', 'baby boy on playground', '', 'baby boy,happy,cute baby,smiling face,white dress,playground', 0, 3, 3, 75, 0, 0, 0, 3, 0, 16, 0, 0, 'admin@wis.com', '2017-04-12', '09:20:46 AM', 'Approved'),
(19, '2017-04-123WdrEcJ0Ma.jpg', 'white', 'crying baby', '', 'baby,crying ,white dress,cute ,sweet little boy', 0, 32, 0, 4, 0, 0, 0, 41, 7, 11, 2, 4, 'admin@wis.com', '2017-04-12', '09:21:42 AM', 'Approved'),
(20, '2017-04-12PnopdTZ37p.jpg', 'blue', 'sleeping baby girl', '', 'long hairs,girl ,baby,sleep,smile,cute', 0, 4, 0, 0, 0, 0, 13, 52, 2, 2, 8, 19, 'admin@wis.com', '2017-04-12', '09:22:50 AM', 'Approved'),
(21, '2017-04-12vEfgrkQhJE.jpg', '', 'cry baby', '', 'cry,little kid,sweet,face crying', 0, 30, 0, 0, 0, 0, 0, 20, 43, 3, 0, 5, 'admin@wis.com', '2017-04-12', '09:23:46 AM', 'Approved'),
(22, '2017-04-12BO3fLZfOdk.jpg', 'green ', 'baby on grass', '', 'girl,grass,palyground,cute,baby', 0, 13, 0, 75, 0, 0, 0, 0, 3, 6, 0, 3, 'admin@wis.com', '2017-04-12', '09:24:39 AM', 'Approved'),
(23, '2017-04-12JFO1DZDdER.jpg', 'yellow dress', 'baby', '', 'sweet baby, yellow dressed boy ', 0, 39, 0, 0, 0, 0, 0, 14, 24, 16, 2, 4, 'admin@wis.com', '2017-04-12', '09:25:25 AM', 'Approved'),
(24, '2017-04-12HrIevFn6nc.jpg', 'white', '', '', 'baby,smile,sweet,cute', 0, 13, 0, 0, 0, 0, 2, 16, 13, 34, 2, 22, 'admin@wis.com', '2017-04-12', '09:26:16 AM', 'Approved'),
(25, '2017-04-12oKbEtFnjYE.jpg', 'green,blue,shinny', 'nature ,landscape,sunray', '', 'nature ,landscape,sunray,sunrise,tree,shallow', 0, 20, 0, 0, 3, 0, 0, 3, 34, 0, 11, 29, 'admin@wis.com', '2017-04-12', '09:36:52 AM', 'Approved'),
(26, '2017-04-1229PiQvxH3d.jpg', 'dark orange,black', 'sunset,sunray', '', 'sunray,sunset,tree,nature ,landscape', 6, 23, 0, 0, 0, 0, 11, 14, 0, 29, 6, 11, 'admin@wis.com', '2017-04-12', '09:37:45 AM', 'Approved'),
(27, '2017-04-123snEQE1DTS.jpg', 'green,white,blue', 'nature', '', 'nature,grass,greenare,women meditation,relex', 0, 0, 0, 63, 0, 0, 0, 3, 9, 9, 3, 14, 'admin@wis.com', '2017-04-12', '09:39:06 AM', 'Approved'),
(28, '2017-04-12BPSKKJPbZl.jpg', 'white,green', 'nature ,forest', '', 'water fall, natural ,landsacpe,nature,water', 0, 0, 0, 25, 6, 4, 0, 0, 4, 2, 58, 0, 'admin@wis.com', '2017-04-12', '09:39:55 AM', 'Approved'),
(29, '2017-04-12HwEfE86lAQ.jpg', 'brown', 'road , way', '', 'trees, green,way,nature', 0, 5, 0, 14, 0, 0, 0, 2, 0, 7, 43, 29, 'admin@wis.com', '2017-04-12', '09:40:49 AM', 'Approved'),
(30, '2017-04-12Qpv3yk98Dd.jpg', 'white', 'bird with feathers', '', 'peakcock ,white peakcock ,feathers open ,bird', 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 'admin@wis.com', '2017-04-12', '10:06:07 AM', 'Approved'),
(31, '2017-04-12lUiT1YfJGp.jpg', 'blue ,green', 'birds', '', 'animal,bird,colour,blue', 0, 19, 0, 19, 0, 6, 0, 0, 3, 34, 9, 9, 'admin@wis.com', '2017-04-12', '10:07:03 AM', 'Approved'),
(32, '2017-04-12HfItqyMnJo.jpg', 'red,green', 'bird', '', 'angry bird,animale,tree,peak', 11, 4, 0, 39, 0, 0, 4, 14, 0, 18, 7, 4, 'admin@wis.com', '2017-04-12', '10:07:55 AM', 'Approved'),
(33, '2017-04-1244zwxZcAK2.jpg', 'yellow', 'love birds', '', 'birds ,nature,mammuls,two birds', 0, 16, 3, 0, 0, 0, 0, 3, 22, 16, 6, 34, 'admin@wis.com', '2017-04-12', '10:08:32 AM', 'Approved'),
(34, '2017-04-12yg7LGoUFAj.jpg', 'colourful', 'fruits,vegetable', '', 'fruits,vegetable,apple,food ,eatable,oranges,tomato,grapes', 0, 23, 2, 6, 0, 0, 0, 2, 0, 0, 8, 58, 'admin@wis.com', '2017-04-12', '10:22:53 AM', 'Approved'),
(35, '2017-04-125oCOXiFp17.jpg', '', 'cake', '', 'cake,food,celebration,birthday,cherry,strawberry,choclate,yummy,tasty', 6, 9, 0, 3, 0, 3, 0, 0, 0, 9, 26, 46, 'admin@wis.com', '2017-04-12', '10:24:23 AM', 'Approved'),
(36, '2017-04-12k2mffQDU0y.jpg', '', 'food', '', 'sticks,food,eatable,chocolate,strawberry,', 17, 9, 0, 0, 0, 0, 0, 3, 37, 6, 9, 20, 'admin@wis.com', '2017-04-12', '10:25:37 AM', 'Approved'),
(37, '2017-04-12IygPpIfjz3.jpg', '', 'south indian food', '', 'south indian food,dosa,idle,sambar,food,tasty,indian,spicy', 0, 28, 0, 13, 0, 0, 0, 8, 0, 13, 8, 33, 'admin@wis.com', '2017-04-12', '10:27:10 AM', 'Approved'),
(38, '2017-04-12CsSUOmA8PC.jpg', '', 'big pizza', '', 'pizza,cheese,food ,eatable,fast food ,junk food', 0, 40, 3, 0, 0, 0, 3, 5, 5, 5, 5, 35, 'admin@wis.com', '2017-04-12', '10:28:13 AM', 'Approved'),
(39, '2017-04-12XoBj1Svq8E.jpg', '', 'food', '', 'pizza,cheese,burgerod ,eatable,fast food ,junk food,spinich', 0, 28, 0, 3, 0, 0, 0, 16, 9, 0, 3, 41, 'admin@wis.com', '2017-04-12', '10:28:52 AM', 'Approved'),
(40, '2017-04-12cramKBLr4I.jpg', '', 'description', '', 'foodies,food,eatable', 0, 31, 0, 0, 0, 0, 0, 0, 3, 0, 3, 63, 'admin@wis.com', '2017-04-12', '10:29:21 AM', 'Approved'),
(41, '2017-04-12sxq8rOS3HZ.jpg', '', 'chicken', '', 'chicken ,food,yummy,indian,fry', 2, 8, 2, 6, 0, 4, 0, 0, 2, 23, 17, 35, 'admin@wis.com', '2017-04-12', '10:31:05 AM', 'Approved'),
(42, '2017-04-12bA9l97rCTT.jpg', '', 'cake yummy', '', 'cake ,cream,butter,cherry,chocolate', 0, 5, 0, 0, 0, 0, 0, 13, 13, 8, 13, 50, 'admin@wis.com', '2017-04-12', '10:31:49 AM', 'Approved'),
(43, '2017-04-12pk35M7Z0An.jpg', '', 'food', '', 'food ,panner,indian,', 0, 25, 3, 30, 0, 0, 0, 15, 15, 3, 0, 10, 'admin@wis.com', '2017-04-12', '10:32:24 AM', 'Approved'),
(44, '2017-04-12Pq1czV9pSx.jpg', '', 'mobile', '', 'mobile,nokia,gadgate,keytype', 0, 0, 0, 4, 2, 6, 0, 2, 37, 14, 33, 2, 'admin@wis.com', '2017-04-12', '12:45:30 PM', 'Approved'),
(45, '2017-04-121K2n8iJ3Hi.jpg', '', 'mobile', '', 'apple iphone 7,gadgate,mobile,high price,phone', 0, 18, 0, 0, 0, 0, 5, 18, 0, 5, 0, 55, 'admin@wis.com', '2017-04-12', '12:46:45 PM', 'Approved'),
(46, '2017-04-12chNMIiPoi3.png', 'silver', 'mobile', '', 'gs6 gold,mobile,gadgate', 0, 0, 0, 4, 13, 7, 2, 18, 9, 13, 34, 2, 'admin@wis.com', '2017-04-12', '12:47:42 PM', 'Approved'),
(47, '2017-04-12U76g2V13NE.jpg', 'red', 'mobile', '', 'iphone 7 ,red ,mobile', 52, 0, 0, 0, 0, 0, 0, 0, 46, 2, 0, 0, 'admin@wis.com', '2017-04-12', '12:48:16 PM', 'Approved'),
(48, '2017-04-129y9SwJuCyV.png', 'black', 'black iphone', '', 'iphone 7 jacket black ,mobile,gadgate', 0, 0, 0, 0, 0, 16, 0, 0, 2, 3, 80, 0, 'admin@wis.com', '2017-04-12', '12:49:04 PM', 'Approved'),
(49, '2017-04-12pxh2Csuc2R.jpg', '', 'mobile', '', ' nokia lumia ,mobile,gadgate', 0, 0, 0, 7, 5, 21, 7, 2, 19, 5, 26, 7, 'admin@wis.com', '2017-04-12', '12:49:56 PM', 'Approved'),
(50, '2017-04-12FKichbSczD.jpg', '', 'mobile', '', 'nokia lumia 657,mobile,windows os', 0, 0, 0, 0, 0, 20, 0, 0, 13, 15, 50, 3, 'admin@wis.com', '2017-04-12', '12:50:42 PM', 'Approved'),
(51, '2017-04-12aCtZ9s0gUf.jpg', '', 'silver mobile', '', 'samsung galaxy j7,android,mobile phone,camera', 0, 44, 0, 0, 0, 0, 0, 29, 2, 4, 4, 17, 'admin@wis.com', '2017-04-12', '12:51:33 PM', 'Approved'),
(52, '2017-04-12nBqzhj9xWh.jpg', 'black', 'mobile', '', 'samsung galaxy c3,android ,mobile ', 0, 0, 0, 2, 0, 13, 0, 0, 17, 0, 69, 0, 'admin@wis.com', '2017-04-12', '12:52:27 PM', 'Approved'),
(53, '2017-04-124I6PDdXOPD.jpg', 'golden', 'laptop', '', 'apple laptop gold,expensive,gadgate,mac book,iphone,apple', 0, 85, 0, 0, 0, 0, 0, 8, 0, 0, 0, 6, 'admin@wis.com', '2017-04-12', '12:57:38 PM', 'Approved'),
(54, '2017-04-12p38jyxF2JV.jpg', '', 'black', '', 'apple laptop black,black,mac book,', 0, 0, 0, 0, 0, 0, 0, 0, 21, 0, 79, 0, 'admin@wis.com', '2017-04-12', '13:00:24 PM', 'Approved'),
(55, '2017-04-12mBDnkMyIEU.jpg', '', 'laptop', '', 'sony laptop,red,', 5, 0, 0, 0, 0, 0, 3, 0, 0, 40, 15, 38, 'admin@wis.com', '2017-04-12', '13:04:23 PM', 'Approved'),
(56, '2017-04-1284elc2zW3E.png', '', '', '', 'sony laptop vivo 203,laptop,gadgets', 0, 0, 0, 0, 0, 6, 19, 6, 44, 16, 6, 3, 'admin@wis.com', '2017-04-12', '13:04:59 PM', 'Approved'),
(57, '2017-04-12h1NYvssuvZ.jpg', '', 'laptop', '', 'sony laptop,with pen start ,gadgets', 0, 0, 0, 3, 0, 6, 13, 0, 50, 16, 13, 0, 'admin@wis.com', '2017-04-12', '13:05:36 PM', 'Approved'),
(58, '2017-04-12ZJzQU2LWOJ.jpg', 'golden', 'Deepika Padukone', '', 'Deepika Padukone,smile,cute,beauty,lady,indian actress,highpaid,goldeb dress,eyes bold', 0, 27, 0, 8, 0, 0, 0, 8, 4, 6, 15, 31, 'admin@wis.com', '2017-04-12', '13:15:17 PM', 'Approved'),
(59, '2017-04-12u0EpqpT8P0.jpg', '', 'Deepika Padukone', '', 'actress,Deepika Padukone,indian look,indian actress,face ,beauty', 0, 21, 0, 0, 0, 0, 2, 21, 0, 0, 17, 38, 'admin@wis.com', '2017-04-12', '13:20:44 PM', 'Approved'),
(60, '2017-04-127E7AoaHImg.jpg', '', 'red dress lady', '', 'deepika-padukone,red dress,hot lady,beautiful', 0, 16, 0, 0, 0, 0, 3, 6, 0, 16, 22, 38, 'shweta@gmail.com', '2017-04-12', '13:23:09 PM', 'Pending'),
(61, '2017-04-124kBEAVey6r.jpg', 'black blue shade', '', '', 'deepika padukone,smile,beauty,diva ,indian', 0, 3, 0, 0, 0, 0, 0, 0, 37, 37, 17, 6, 'shweta@gmail.com', '2017-04-12', '13:27:19 PM', 'Pending'),
(62, '2017-04-12QHWnvhYFQ2.jpg', '', 'pink dress', '', 'deepika-padukone,pink outfit', 3, 0, 0, 0, 0, 0, 20, 8, 0, 38, 20, 13, 'shweta@gmail.com', '2017-04-12', '13:28:01 PM', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `suggetion_box`
--

CREATE TABLE IF NOT EXISTS `suggetion_box` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent_from` text NOT NULL,
  `suggetion_message` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `suggetion_box`
--

INSERT INTO `suggetion_box` (`id`, `sent_from`, `suggetion_message`, `date`, `time`) VALUES
(4, 'aishwarya@gmail.com', 'sdfsdfs', '2016-12-28', '20:53:25 PM'),
(5, 'aishwarya@gmail.com', 'dsfg', '2016-12-28', '20:53:26 PM'),
(6, 'aishwarya@gmail.com', 'hkhttit', '2016-12-28', '20:54:21 PM');

-- --------------------------------------------------------

--
-- Table structure for table `user_interests`
--

CREATE TABLE IF NOT EXISTS `user_interests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interest_of` text NOT NULL,
  `keywords` text NOT NULL,
  `image_type` text NOT NULL,
  `color` text NOT NULL,
  `size` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_interests`
--

INSERT INTO `user_interests` (`id`, `interest_of`, `keywords`, `image_type`, `color`, `size`, `date`, `time`) VALUES
(2, 'aishwarya@gmail.com', 'sdasd', 'clip art', 'transparent', '15MP(4480-3360)', '2016-12-23', '07:06:17 AM');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
