<?php
	require_once("lib/functions.php");
	$db = new db_functions();
?>
<html>
<head>
	<title>Web Image Search</title>
<link href="/images/iconsearch.jpg" rel="shortcut icon" />
	<link rel="stylesheet" type="text/css" href="/assets/fancybox/jquery.fancybox-1.3.4.css" />
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
	<link rel="stylesheet" type="text/css" href="/assets/css/styles.css" />
	<script type="text/javascript" src="/js/jquery-1.10.2.js"></script>
	<script>
	$(document).ready(function(){
		$("#image_b_s").click(function(){
			$("#img_panel").show();
		});
		$("#text_b_s").click(function(){
			$("#img_panel").hide();
		});
	});
	</script>
	<script>
	$(document).ready(function(){
		$("#browse_i").click(function(){
			$("#img_subpanel").show();
		});
		$("#take_photo_i").click(function(){
			$("#img_subpanel").hide();
		});
	});
	</script>
	<script>
	$(document).ready(function(){
		$("#take_photo_i").click(function(){
			$("#img_subpanel1").show();
		});
		$("#browse_i").click(function(){
			$("#img_subpanel1").hide();
		});
	});
	</script>
</head>
<body style="background-image:url('/images/back1.jpg'); background-size:100% 100%;">

	<div class="main_page_serch_container">
		<div class="mid_panel">
		<h1 class="mp_sitename">Web Image Search</h1>
		<br />
	<form action="search-results.php" method="post" enctype="multipart/form-data">
		<input type="text" name="search_box" class="search_box" placeholder="Enter your search query" />
		
		<div class="rdo_btns_contnr">
			<label><input type="radio" name="search_criteria" value="text_based_search" id="text_b_s" class="rdobtns" checked />Text Based Search</label>
			<label><input type="radio" name="search_criteria" value="image_based_search" id="image_b_s" class="rdobtns" />Image Based Search</label>
			<br />
			<div class="image_based_search" id="img_panel">
			<label><input type="radio" name="image_fetch" value="browse" id="browse_i" class="rdobtns" checked />Browse</label>
			<label><input type="radio" name="image_fetch" value="take_photo" id="take_photo_i" class="rdobtns" />Take Your Photo</label>
			
			
			<div class="image_based_search" id="img_subpanel">
			<input type="file" name="photoimg" id="inp_file" value="" style="padding:8px; background-color:#EFEFEF; margin-top:15px; cursor:pointer;" />
			</div>
			<br />
			
			<div class="image_based_search" id="img_subpanel1" style="display: none;">
			<div id="photos"></div>
			<div id="camera">
				<span class="tooltip"></span>
				<span class="camTop"></span>
				
				<div id="screen"></div>
				<div id="buttons">
					<div class="buttonPane">
						<a id="shootButton" href="" class="blueButton">Shoot!</a>
					</div>
					<div class="buttonPane hidden">
						<a id="cancelButton" href="" class="blueButton">Cancel</a> <a id="uploadButton" href="" class="greenButton">Upload!</a>
					</div>
				</div>
				</div>
				
			</div>
			
		</div>
		</div>
		<input type="submit" name="search_btn" class="search_btn" value="search"/>
		</form>
		<br/>
		
		</div>
	</div>
	


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="/assets/fancybox/jquery.easing-1.3.pack.js"></script>
<script src="/assets/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<script src="/assets/webcam/webcam.js"></script>
<script src="/assets/js/script.js"></script>	
	<div style="height:170px;"></div>
	<?php
		require_once('footer.php');
	?>
</body>
</html>