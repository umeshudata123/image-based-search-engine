-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2018 at 07:17 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `web_image_search`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` text NOT NULL,
  `password` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user_id`, `password`, `date`, `time`) VALUES
(1, 'admin@wis.com', 'admin', '2016-12-24', '01:00:00:PM');

-- --------------------------------------------------------

--
-- Table structure for table `applications_users`
--

CREATE TABLE IF NOT EXISTS `applications_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` text NOT NULL,
  `contact_number` text NOT NULL,
  `email_id` text NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` text NOT NULL,
  `password` text NOT NULL,
  `otp_no` text NOT NULL,
  `otp_status` text NOT NULL,
  `profile` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `applications_users`
--

INSERT INTO `applications_users` (`id`, `user_name`, `contact_number`, `email_id`, `date_of_birth`, `gender`, `password`, `otp_no`, `otp_status`, `profile`, `date`, `time`) VALUES
(41, 'aishwarya', '225454', 'aishwarya@gmail.com', '1996-07-05', 'Female', '12345', '95031', '', '', '2016-10-18', '08:38:54'),
(42, 'Shweta', '2222222222', 'shweta@gmail.com', '1995-07-09', 'Select Gender', 'shweta', '95033', 'Pending', '', '2016-12-26', '05:54:35'),
(43, 'Shrikant Kadam', '9595775120', 'shri@gmail.com', '2016-01-14', 'Male', 'password', '95034', 'Pending', '', '2017-01-15', '00:31:25 AM'),
(44, '12344', '2222222222', 'kd@gmail.com', '0000-00-00', 'Female', '12345', '95035', 'Pending', '', '2017-03-16', '06:46:38'),
(45, 'poonam', '3333333333', 'poonam@gmail.com', '0000-00-00', 'Female', '12345', '95036', 'Approve', '', '2017-03-18', '06:46:07'),
(46, 'shrikant', '1234567890', 'shree@gmail.com', '0000-00-00', 'Male', '1234', '95032', 'Pending', '', '2017-12-18', '10:15:46'),
(47, 'raj1234', '9557', 'raj@gmail.com', '0000-00-00', 'Male', '123456', '92563', 'Approve', 'lne2DSG64D.jpg', '2017-12-25', '04:21:16'),
(48, 'raj123', '9557848970', 'raj123@gmail.com', '0000-00-00', 'Male', '123456', '31974', 'Pending', '', '2017-12-25', '04:49:06'),
(49, 'aa', '6846564455', 'aa@gmail', '0000-00-00', 'Male', '11111111', '84221', 'Pending', '', '2017-12-31', '04:38:42'),
(50, 'jsuiajh', '4587963214', 'asa@gmail.com', '0000-00-00', 'Select Gender', '000000', '40660', 'Pending', '', '2017-12-31', '04:39:34'),
(51, 'axa', '4545454545', 'aass@gmail.com', '0000-00-00', 'Select Gender', '12121212', '89569', 'Pending', '', '2017-12-31', '04:42:06'),
(52, 'umesh', '4545658545', 'uu@gmail.com', '0000-00-00', 'Select Gender', '112121', '76232', 'Pending', '', '2017-12-31', '04:44:52'),
(53, 'sonali', '9890835371', 'sk@gmail.com', '0000-00-00', 'Female', 'rani', '21003', 'Pending', '', '2018-02-12', '09:37:51'),
(54, 'umesh', '7898964565', 'uu12@gmail.com', '0000-00-00', 'Male', '000000', '99604', 'Pending', '', '2018-02-19', '08:22:26'),
(55, 'Manoj', '9158432138', 'mskamshetti@gmail.com', '0000-00-00', 'Male', 'manoj123', '', '', '', '2018-03-01', '10:46:19');

-- --------------------------------------------------------

--
-- Table structure for table `blocked_images`
--

CREATE TABLE IF NOT EXISTS `blocked_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blocked_image_name` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `blocked_images`
--

INSERT INTO `blocked_images` (`id`, `blocked_image_name`, `date`, `time`) VALUES
(6, '2017-04-12hUkwOkhT2b.jpg', '2017-04-12', '08:51:16 AM');

-- --------------------------------------------------------

--
-- Table structure for table `deleted_image`
--

CREATE TABLE IF NOT EXISTS `deleted_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `added_by` text NOT NULL,
  `image` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `deleted_image`
--

INSERT INTO `deleted_image` (`id`, `added_by`, `image`, `date`, `time`) VALUES
(1, 'shree@gmail.com', '2017-03-10pTrMgSDcxC.jpg', '2017-12-18', '09:49:10 AM'),
(2, 'shree@gmail.com', '2017-03-10oknDlIBuUZ.jpg', '2017-12-18', '09:59:47 AM'),
(3, 'aishwarya@gmail.com', '2017-03-11QNuzIylzVQ.jpg', '2017-12-18', '09:59:57 AM'),
(4, 'shree@gmail.com', '2017-03-10AFOJh1uCyk.jpg', '2017-12-18', '10:00:03 AM'),
(5, 'admin@wis.com', '2017-03-16I936vgansK.jpg', '2017-12-18', '10:06:32 AM'),
(6, 'admin@wis.com', '2017-03-18XG3eg3PFer.jpg', '2017-12-18', '10:07:07 AM'),
(7, 'shree@gmail.com', '2017-03-10YrPNibRZYb.jpg', '2017-12-18', '10:07:16 AM'),
(8, 'aishwarya@gmail.com', '2017-12-18iaF0OoUXVh.jpg', '2017-12-18', '10:45:00 AM'),
(9, 'raj@gmail.com', '2017-12-25G0ObjvVTGH.jpg', '2017-12-25', '04:41:30 AM'),
(10, 'raj@gmail.com', '2017-12-25jdtzJKW1We.jpg', '2017-12-25', '04:42:29 AM'),
(11, 'aishwarya@gmail.com', '2017-12-19QZhJlEyvEX.jpg', '2017-12-31', '04:33:23 AM'),
(12, 'raj@gmail.com', '2017-12-31KFE3IVT7ud.jpg', '2018-01-28', '07:10:55 AM');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_name` text NOT NULL,
  `colours` text NOT NULL,
  `description` text NOT NULL,
  `image_type` text NOT NULL,
  `keywords` text NOT NULL,
  `red` int(11) NOT NULL,
  `orange` int(11) NOT NULL,
  `yellow` int(11) NOT NULL,
  `green` int(11) NOT NULL,
  `turquoise` int(11) NOT NULL,
  `blue` int(11) NOT NULL,
  `purple` int(11) NOT NULL,
  `pink` int(11) NOT NULL,
  `white` int(11) NOT NULL,
  `gray` int(11) NOT NULL,
  `black` int(11) NOT NULL,
  `brown` int(11) NOT NULL,
  `posted_by` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  `status` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `red`, `orange`, `yellow`, `green`, `turquoise`, `blue`, `purple`, `pink`, `white`, `gray`, `black`, `brown`, `posted_by`, `date`, `time`, `status`) VALUES
(2, '2017-03-10f6zixlhbbx.gif', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 57, 0, 'shree@gmail.com', '2017-03-10', '18:52:38 PM', 'Pending'),
(4, '2017-03-10N3X1kkIOGE.jpg', '', '', '', '', 7, 26, 7, 10, 0, 10, 5, 19, 5, 0, 2, 10, 'shree@gmail.com', '2017-03-10', '18:52:47 PM', 'Pending'),
(6, '2017-03-10VCrYgDIi8l.jpg', '', '', '', '', 2, 50, 0, 0, 0, 0, 0, 19, 0, 0, 2, 27, 'shree@gmail.com', '2017-03-10', '18:53:04 PM', 'Pending'),
(7, '2017-03-10yqvlHHQImX.jpg', '', '', '', '', 0, 50, 13, 0, 0, 0, 0, 13, 13, 0, 3, 9, 'shree@gmail.com', '2017-03-10', '18:53:10 PM', 'Pending'),
(8, '2017-03-10WkiNGmutGi.jpg', '', '', '', '', 3, 41, 0, 0, 0, 0, 8, 16, 2, 0, 5, 27, 'shree@gmail.com', '2017-03-10', '18:53:15 PM', 'Pending'),
(10, '2017-03-11eyNuzkQA5C.jpg', 'brown', 'cake with cherrys and strawberrys', 'jpg', 'cake,food,birthday,cherry,choclate,strawberry,cream,plate,hungry', 0, 6, 0, 10, 0, 0, 2, 6, 6, 27, 23, 19, 'shri@gmail.com', '2017-03-11', '02:50:22 AM', 'Approved'),
(13, '2017-03-16JLyVsXr8Ky.jpg', '', 'Image of hollywood actress', '', 'Kristen, red lips, beautiful girl, hollywood actress, fair lady', 0, 11, 0, 0, 0, 0, 0, 18, 0, 4, 43, 25, 'admin@wis.com', '2017-03-16', '08:30:13 AM', 'Approved'),
(14, '2017-03-16yXMpP1jPMo.jpg', '', 'lady with white dress', '', 'white dressed lady, kristen, actress, hollywood, twilight, vampire movie actress', 0, 6, 0, 0, 0, 0, 0, 4, 8, 23, 25, 33, 'admin@wis.com', '2017-03-16', '08:32:20 AM', 'Approved'),
(15, '2017-03-16xGlGbi0Ytx.jpg', '', 'Actress with brownish hair kristen', '', 'Kristen Stewart, smiley look, brown hairs, cute smile', 0, 13, 0, 0, 0, 0, 0, 3, 3, 0, 68, 15, 'admin@wis.com', '2017-03-16', '08:33:06 AM', 'Approved'),
(17, '2017-03-17cByWLUHvQm.jpg', 'blue', 'image of cute baby', 'jpg', 'cute,innocent,baby,small', 0, 8, 0, 0, 2, 6, 0, 4, 38, 38, 0, 4, 'admin@wis.com', '2017-03-17', '13:56:38 PM', 'Approved'),
(18, '2017-03-17YC0EHMn2JV.jpg', 'brown', 'testy pestry', 'jpg', 'testy,cherry,chocolate,pestry\r\n', 13, 10, 0, 0, 0, 0, 8, 8, 0, 8, 23, 33, 'admin@wis.com', '2017-03-17', '13:59:33 PM', 'Approved'),
(20, '2017-03-17AyaagooIXz.jpg', 'pink', 'baby image hey text', 'jpg', 'cute,innocent,small,baby', 8, 3, 0, 0, 0, 0, 5, 30, 38, 15, 0, 3, 'admin@wis.com', '2017-03-17', '14:02:29 PM', 'Approved'),
(21, '2017-03-17T8w3faijx2.jpg', '', 'black forest cake', 'jpg', 'testy,sweet,cake,cherry,vanilla cream', 2, 0, 0, 2, 0, 0, 0, 2, 30, 13, 27, 25, 'admin@wis.com', '2017-03-17', '14:04:34 PM', 'Approved'),
(22, '2017-03-178kmrlyOBOY.jpg', '', 'black forest cake with cherry', 'jpg', 'cake,testy,cream,cherry,chocolate cream,vanilla', 5, 2, 0, 0, 0, 0, 0, 11, 27, 20, 14, 22, 'admin@wis.com', '2017-03-17', '14:06:35 PM', 'Approved'),
(23, '2017-03-17vfR2vBlJpn.jpg', '', 'cake with chocolate flavour', 'jpg', 'chocolate,cream,testy,sweet', 0, 10, 0, 0, 0, 0, 2, 2, 29, 18, 14, 24, 'admin@wis.com', '2017-03-17', '14:09:04 PM', 'Approved'),
(24, '2017-03-17AvkNsmQygJ.jpg', '', 'chocolate cream cake', '', 'cake, desert, chocolate cream, delicious, tasty, brownie', 0, 2, 0, 0, 0, 0, 8, 2, 10, 10, 12, 55, 'admin@wis.com', '2017-03-17', '14:15:19 PM', 'Approved'),
(25, '2017-03-173UTByxFrrH.jpg', 'pink', 'baby with cute smile', '', 'baby, pink hat, cute eyes, sweet baby, ', 0, 21, 0, 0, 0, 0, 2, 65, 8, 0, 0, 4, 'admin@wis.com', '2017-03-17', '14:16:26 PM', 'Approved'),
(26, '2017-03-17qdi5wodVNW.jpg', '', 'smiling baby', '', 'happy baby, smile, brown hat, eyes', 0, 6, 0, 0, 0, 0, 9, 63, 0, 9, 0, 13, 'admin@wis.com', '2017-03-17', '14:17:11 PM', 'Approved'),
(27, '2017-03-17NVAk8kKxPP.png', '', 'vanilla cake', '', 'cake, vanilla cream, chocolate cream', 0, 0, 0, 0, 0, 0, 5, 5, 28, 38, 20, 5, 'admin@wis.com', '2017-03-17', '14:17:44 PM', 'Approved'),
(28, '2017-03-17WPW4sFNdlB.jpg', '', 'baby with green blanket', '', 'smiling baby, cute eyes, green blanket', 0, 18, 0, 8, 0, 0, 3, 13, 48, 0, 0, 13, 'admin@wis.com', '2017-03-17', '14:18:55 PM', 'Approved'),
(29, '2017-03-17C7Bc3nerWX.jpg', '', 'birthday cake', '', 'cake, birthday', 0, 0, 0, 3, 0, 0, 3, 10, 25, 15, 3, 43, 'admin@wis.com', '2017-03-17', '14:19:26 PM', 'Approved'),
(30, '2017-03-17oVRzt7Ush0.jpg', '', 'black forest cake', '', 'cake, cherry, food, birthday, sweet, desert', 4, 4, 0, 0, 0, 0, 0, 4, 15, 0, 25, 48, 'admin@wis.com', '2017-03-17', '14:20:04 PM', 'Approved'),
(31, '2017-03-17Hka2hpZcio.jpg', '', 'mixed flavoured cake', '', 'cake, all flavors, nuts, sweet', 0, 9, 0, 0, 0, 0, 2, 5, 9, 7, 32, 36, 'admin@wis.com', '2017-03-17', '14:20:46 PM', 'Approved'),
(32, '2017-03-17C1XE2K8wmc.jpg', '', 'nature images', '', 'street, trees, nature, lonely', 0, 3, 0, 35, 0, 0, 0, 0, 3, 25, 20, 15, 'admin@wis.com', '2017-03-17', '14:37:22 PM', 'Approved'),
(33, '2017-03-17qFpksMyCi6.jpg', '', 'nature image for sunrise or sunset', '', 'sunset, tree, birds', 0, 26, 3, 0, 0, 0, 0, 3, 0, 0, 3, 66, 'admin@wis.com', '2017-03-17', '14:38:25 PM', 'Approved'),
(34, '2017-03-17C1ylY1jJqA.jpg', '', 'sunset images of nature', '', 'sunset, nature, lonely', 0, 40, 0, 9, 0, 17, 0, 0, 0, 11, 23, 0, 'admin@wis.com', '2017-03-17', '14:38:54 PM', 'Approved'),
(35, '2017-03-17lDFRsj1bsG.jpg', '', 'sunrise images of nature', '', 'nature, sunrise, beach, water, ocean', 0, 21, 0, 4, 17, 42, 0, 8, 0, 8, 0, 0, 'admin@wis.com', '2017-03-17', '14:39:38 PM', 'Approved'),
(36, '2017-03-17vKdLIj2ZK4.jpg', '', 'train track in nature', '', 'nature, train track,trees', 0, 0, 0, 49, 0, 0, 0, 0, 0, 3, 49, 0, 'admin@wis.com', '2017-03-17', '14:40:12 PM', 'Approved'),
(37, '2017-03-17bXlbehyL5o.jpg', '', 'sunset or sunrise', '', 'image, nature, sun,  sunrise, sunset', 43, 25, 8, 0, 0, 0, 0, 0, 0, 0, 0, 25, 'admin@wis.com', '2017-03-17', '14:43:33 PM', 'Approved'),
(39, '2017-03-17XLcQRwWGnN.jpg', '', 'nature images', '', 'hillstation, nature, hills', 0, 25, 0, 0, 0, 0, 13, 0, 0, 33, 8, 21, 'admin@wis.com', '2017-03-17', '14:44:52 PM', 'Approved'),
(40, '2017-03-18PDq9y3wHnM.jpg', 'gray', 'The bmw car', 'jpg', 'bmw,metal body,shiny look,four wheeler,branded car,royal look', 0, 0, 0, 3, 0, 0, 0, 0, 31, 43, 20, 3, 'admin@wis.com', '2017-03-18', '03:24:53 AM', 'Approved'),
(41, '2017-03-18C3Y8agBZaY.jpg', 'redish ', 'the bmw car', 'jpg', 'bmw,metal body ,shiny ,royal,four wheeler,silver ', 6, 3, 0, 0, 0, 0, 0, 0, 29, 14, 23, 26, 'admin@wis.com', '2017-03-18', '03:27:20 AM', 'Approved'),
(43, '2017-03-18LaPZHEIBS0.jpg', 'green', 'The lamborghini car', 'jpg', 'green,lamborghini,black glass,shiny', 0, 0, 0, 63, 0, 0, 0, 4, 17, 4, 13, 0, 'admin@wis.com', '2017-03-18', '03:35:07 AM', 'Approved'),
(75, '2017-04-12xf1JDbegXt.jpg', '', 'fridge', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 38, 63, 0, 0, 'admin@wis.com', '2017-04-12', '07:50:05 AM', 'Approved'),
(77, '2017-04-120gjyrjendV.jpg', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 39, 61, 0, 0, 'admin@wis.com', '2017-04-12', '08:51:57 AM', 'Approved'),
(79, '2017-12-18pD7ifN08Ew.gif', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 'aishwarya@gmail.com', '2017-12-18', '10:44:14 AM', 'Pending'),
(82, '2018-03-01tL8O6RlKPY.png', '', '', '', '', 0, 13, 0, 0, 0, 15, 4, 23, 21, 19, 4, 2, 'mskamshetti@gmail.com', '2018-03-01', '10:50:09 AM', 'Pending'),
(83, '2018-03-015qKFTaQTlP.png', 'fgfgf', 'gfgfdgfg', 'jpg', 'ygyg', 0, 2, 0, 19, 6, 15, 2, 4, 23, 2, 25, 2, 'mskamshetti@gmail.com', '2018-03-01', '10:55:15 AM', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `suggetion_box`
--

CREATE TABLE IF NOT EXISTS `suggetion_box` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent_from` text NOT NULL,
  `sent_to` text NOT NULL,
  `suggetion_message` text NOT NULL,
  `reply_to` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `suggetion_box`
--

INSERT INTO `suggetion_box` (`id`, `sent_from`, `sent_to`, `suggetion_message`, `reply_to`, `date`, `time`) VALUES
(11, 'poonam@gmail.com', '', 'hey poonam here', '', '2017-12-18', '09:33:41 AM'),
(12, 'admin', 'poonam@gmail.com', 'hey admin here what happened', '11', '2017-12-18', '09:34:05'),
(13, 'aishwarya@gmail.com', '', 'hey aishwarya here', '', '2017-12-18', '09:34:51 AM'),
(14, 'admin', 'poonam@gmail.com', 'hello aishwarya', '11', '2017-12-18', '09:35:15'),
(15, 'admin', 'aishwarya@gmail.com', 'hello aishwarya \r\n\r\n', '13', '2017-12-18', '09:35:43'),
(16, 'admin', 'poonam@gmail.com', 'dhfhjghjhgj', '11', '2017-12-18', '09:36:05'),
(17, 'admin', 'poonam@gmail.com', ',mbn,hbn,mn', '11', '2017-12-18', '09:36:14'),
(18, 'admin', 'aishwarya@gmail.com', 'uuuuuuu', '13', '2017-12-18', '10:40:28'),
(19, 'admin', 'aishwarya@gmail.com', 'ghfytfty', '13', '2017-12-18', '10:45:42'),
(20, 'admin', 'aishwarya@gmail.com', 'okok', '13', '2017-12-19', '11:37:30'),
(21, 'aishwarya@gmail.com', '', 'cmkdmkc', '', '2017-12-19', '11:38:57 AM'),
(22, 'aishwarya@gmail.com', '', 'axsxa', '', '2017-12-19', '11:40:52 AM'),
(23, 'raj@gmail.com', '', 'fejdkfdkjkfj\r\n', '', '2017-12-25', '04:29:04 AM'),
(24, 'admin', 'raj@gmail.com', 'fdusyfdhjshdn', '23', '2017-12-25', '04:29:48'),
(25, 'raj@gmail.com', '', 'fejdkfdkjkfj\r\n', '', '2017-12-25', '04:29:55 AM'),
(26, 'raj@gmail.com', '', 'umesh', '', '2017-12-25', '04:30:14 AM'),
(27, 'admin', 'raj@gmail.com', 'fdusyfdhjshdn', '23', '2017-12-25', '04:30:24'),
(28, 'admin', 'raj@gmail.com', 'okok', '26', '2017-12-25', '04:30:41'),
(29, 'raj@gmail.com', '', 'umesh', '', '2017-12-25', '04:30:55 AM'),
(30, 'raj@gmail.com', '', 'raj', '', '2017-12-25', '04:31:37 AM'),
(31, 'admin', 'raj@gmail.com', 'umesh', '30', '2017-12-25', '04:32:07'),
(32, 'admin', 'raj@gmail.com', 'kljxhiuhgdjkbn df', '30', '2017-12-31', '04:34:00'),
(33, 'admin', 'raj@gmail.com', 'hbvhjbn ', '30', '2018-03-01', '10:56:45');

-- --------------------------------------------------------

--
-- Table structure for table `user_interests`
--

CREATE TABLE IF NOT EXISTS `user_interests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interest_of` text NOT NULL,
  `keywords` text NOT NULL,
  `image_type` text NOT NULL,
  `color` text NOT NULL,
  `size` text NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user_interests`
--

INSERT INTO `user_interests` (`id`, `interest_of`, `keywords`, `image_type`, `color`, `size`, `date`, `time`) VALUES
(2, 'aishwarya@gmail.com', 'car cake', 'clip art', 'transparent', '15MP(4480-3360)', '2017-04-13', '03:59:01 AM'),
(3, 'raj@gmail.com', 'car', '', 'black and white', '', '2017-12-27', '12:32:13 PM'),
(4, 'mskamshetti@gmail.com', 'Gods, Nature', 'animated', '', '', '2018-03-01', '10:49:29 AM');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
