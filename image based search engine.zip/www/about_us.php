<?php
	require_once("lib/functions.php");
	$db = new db_functions();
?>	
<html>
<head>
	<title>About Us</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>

<?php 
	require_once('header.php');
?>

	<div class="middle_section" style="min-height:560px">
ABOUT INFORMATION HERE
			</div>
				<style>
		body{
			background-image: url("images/background-websites-26-desktop-background-and-wallpaper-900x568.jpg");
			background-repeat:no-repeat;

			background-size:cover; 
		}
	</style>


		
	</div>

		

<?php
	require_once('footer.php');
?>


</body>
</html>