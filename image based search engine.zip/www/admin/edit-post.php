<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	if(!isset($_SESSION['current_login_admin']))
	{
		header("Location:/signin.php");
	}
	$cur_post_id	=	"";
	if(isset($_GET['edt_id']))
	{
		$cur_post_id	=	$_GET['edt_id'];
		$_SESSION['cur_post_id']	=	$cur_post_id;
	}
	else if(isset($_SESSION['cur_post_id']))
	{
		$cur_post_id	=	$_SESSION['cur_post_id'];
	}
	
	$block_flag		=	0;
	$success_flag	=	0;
	
	$current_login_admin	=	$_SESSION['current_login_admin'];
	
	if(isset($_POST['form_submit_btn']))
	{
		$colours			=	$_POST['colours'];
		$description		=	$_POST['description'];
		$keywords			=	$_POST['image_keywords'];
		$type				=	$_POST['image_type'];
		
		if($db->update_my_image_details_admin($colours,$description,$keywords,$type,$cur_post_id))
		{
			$success_flag	=	1;
		}
	}	
?>
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	<?php
		require_once("../header.php");
		
		$res_id			=	"";
		$res_image_name	=	"";
		$res_colours	=	"";
		$res_description=	"";
		$res_image_type	=	"";
		$res_keywords	=	"";
		$res_posted_by	=	"";
		$res_date		=	"";
		$res_time		=	"";
		$res_status		=	"";
		
			$my_images	=	array();
			
			$my_images	=	$db->get_all_my_uploaded_images_by_id_wise($cur_post_id);
			
			if(!empty($my_images))
			{
				$counter	=	0;
				
				foreach($my_images as $image)
				{	
					$res_id			=	$my_images[$counter][0];
					$res_image_name	=	$my_images[$counter][1];
					$res_colours	=	$my_images[$counter][2];
					$res_description=	$my_images[$counter][3];
					$res_image_type	=	$my_images[$counter][4];
					$res_keywords	=	$my_images[$counter][5];
					$res_posted_by	=	$my_images[$counter][6];
					$res_date		=	$my_images[$counter][7];
					$res_time		=	$my_images[$counter][8];
					$res_status		=	$my_images[$counter][9];
				}
			}
	?>
	<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	
	<?php
		require_once('user_menus.php');
	?>
	<div class="page_head_titles">Edit User Image</div>
		<center><a href="/admin/user-uploads.php">Back To user Uploads</a></center>
		<div class="form_container" style="width:auto;">
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
			<?php
				if($success_flag==1)
				{
			?>
			<div class="alert_msgs">Details Updated Successfully </div>
			<?php
				}
			?>
			
			<input type="text" name="colours" class="form_txtbx" placeholder="Enter colours of image" value="<?php echo $res_colours; ?>" />
			<input type="text" name="image_type" class="form_txtbx" placeholder="Enter image type" value="<?php echo $res_image_type; ?>" />
			<textarea name="description" class="form_txtbx" placeholder="Enter description for image"><?php echo $res_description; ?></textarea>
			<textarea name="image_keywords" class="form_txtbx" placeholder="Enter keywords for image"><?php echo $res_keywords; ?></textarea>
			
			<br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Update"/>
		</form>
	
	</div>
	
	
	<div class="my_image_container">
	
		<?php
			$del_flag	=	0;
			if(isset($_GET['del_id']) AND isset($_GET['img']))
			{	
				$delete_id	=	$_GET['del_id'];
				$image_name	=	$_GET['img'];
				
				if($image_name!="")
				{
					unlink('../gallery/'.$image_name);
				}
				
				if($db->delete_current_image($delete_id))
				{
					$del_flag	=	1;
				}
			}
			
			if($del_flag==1)
			{
		?>
			<div class="success_msg"><?php echo $image_name; ?> - Image deleted successfully</div>
		<?php
			}
			
			
			$my_images	=	array();
			
			$my_images	=	$db->get_all_my_uploaded_images_by_id_wise($cur_post_id);
			
			if(!empty($my_images))
			{
				$counter	=	0;
				
				foreach($my_images as $image)
				{	
					$res_id			=	$my_images[$counter][0];
					$res_image_name	=	$my_images[$counter][1];
					$res_colours	=	$my_images[$counter][2];
					$res_description=	$my_images[$counter][3];
					$res_image_type	=	$my_images[$counter][4];
					$res_keywords	=	$my_images[$counter][5];
					$res_posted_by	=	$my_images[$counter][6];
					$res_date		=	$my_images[$counter][7];
					$res_time		=	$my_images[$counter][8];
					$res_status		=	$my_images[$counter][9];
		?>
			<div class="img_display_thumb" style="display:inline-table;">
			<a href="/gallery/<?php echo $res_image_name; ?>" target="_blank"><img src="/gallery/<?php echo $res_image_name; ?>" class="img_thumb" /></a><br />
			<a href="<?php echo $_SERVER['PHP_SELF']."?del_id=".$res_id."&img=".$res_image_name; ?>" class="link">Delete</a>
			<?php
				if($res_status=="Approved")
				{
			?>
			<label style="color:Green">
			(<?php echo $res_status; ?>)
			</label>
			<?php
				}
				else
				{
			?>
			<label style="color:RED">
			(<?php echo $res_status; ?>)
			</label>
			<?php
				}
			?>
			</div>
		<?php
					$counter++;
				}
			}
		?>
		
	</div>
	
	</div>
</body>
<?php
	require_once("../footer.php");
?>
