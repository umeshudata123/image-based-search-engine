	
	<div class="user_menus">
			
			<a href="/admin/set-blocked-images.php" class="mp_menu">Set Blocked Image</a>
			
			<a href="/admin/user-uploads.php" class="mp_menu">User Uploads</a>
			<a href="/admin/change_password.php" class="mp_menu">Change Password</a>
			<a href="/admin/suggetion_queries.php" class="mp_menu">Suggetion Box</a>
			<div class="User_name">
				<a class="menu">
				<?php
					echo $_SESSION['current_login_admin'];
				?></a>
				<a href="/admin/index.php?lout_c_u" >Logout</a>
			</div>
	</div>

