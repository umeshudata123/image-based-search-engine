<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	$admin_session_id	=	$_SESSION['current_login_admin'];
	
	if(!isset($_SESSION['current_login_admin']))
	{
		header("Location:/signin.php");
	}
	
	$email_id	=	"";
	
	$flag		=	0;
	
	$updation_error		= "";
	$password_error		= "";
	$conf_pwd_error		= "";
	$curr_pwd_error		= "";
	
	$curr_pwd	=	"";
	$new_pwd	=	"";
	$conf_pwd	=	"";
	
	if(isset($_POST['form_submit_btn']))
	{
		$curr_pwd=$_POST['current_password'];
		$new_pwd=$_POST['new_password'];
		$conf_pwd=$_POST['new_confpwd'];
		
		if(strlen($curr_pwd)<4 && strlen($new_pwd)<4 && strlen($conf_pwd)<4)
		{
			$password_error		=	"Please enter at least 4 characters";
			$flag 				=	1;
		}
		
		if($new_pwd!=$conf_pwd)
		{
			$conf_pwd_error		=	"Please match the password";
			$flag 				=	1;
		}
			
		$password	=	$db->check_admin_exist($admin_session_id);
			
		if($curr_pwd!=$password)
		{
			$curr_pwd_error 	=	"Invalid Current Password";
			$flag 				=	1;
		}
		if($flag==0)
		{
			
			if($db->change_admin_password($new_pwd,$admin_session_id))
			{
				$updation_error		=	"Password Updated Successfully";
			}
			else
			{
				$updation_error		=	"Error in Password Updation";
			}
		}
	}
?>


<html>
<head>
	<title>Change Password</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>


<?php 
	require_once('../header.php');
?>

<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	<?php
		require_once('user_menus.php');
	?>
	<div class="page_head_titles">Change Password</div>
	
	<div class="form_container">
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
			
			<span class="error_indicator"><?php echo $updation_error; ?></span>
		
			<input type="password" name="current_password" class="form_txtbx" placeholder="Enter current password" required />
			<span class="error_indicator"><?php echo $curr_pwd_error; ?></span>
			<input type="password" name="new_password" class="form_txtbx" placeholder="Enter new password" required />
			<span class="error_indicator"><?php echo $password_error; ?></span>
			<input type="password" name="new_confpwd" class="form_txtbx" placeholder="Confirm new password" required  />
			<span class="error_indicator"><?php echo $conf_pwd_error; ?></span>
			
			</select>
			
			<br /><br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Submit"/>
		</form>
	</div>
</div>

<?php
	require_once('../footer.php');
?>


</body>
</html>