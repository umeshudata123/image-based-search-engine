<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	if(!isset($_SESSION['current_login_admin']))
	{
		header("Location:/admin/index.php");
	}
?>
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	<?php
	require_once("../header.php");
	?>
	<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	
	<div class="admin_image_container">	
	<?php
		require_once('user_menus.php');
	?>
	
	<br /><br />
	<div class="section_title">Pending Gallery Images</div>
	<?php
		
		$del_flag	=	0;
			if(isset($_GET['del_id']) AND isset($_GET['img']) AND isset($_GET['posted']))
			{	
				$delete_id	=	$_GET['del_id'];
				$image_name	=	$_GET['img'];
				$posted		=	$_GET['posted'];
				$db->admin_deleted_image($posted,$image_name);
				if($db->delete_current_image($delete_id))
				{
					$del_flag	=	1;
					header("Location:user-uploads.php");
				}
				
				
			}
			
			if(isset($_GET['approve_id']))
			{
				$approve_id	=	$_GET['approve_id'];
				
				$db->approve_user_image($approve_id);
			}
			
			$my_images	=	array();
			
			$status		=	"Pending";
			
			$my_images	=	$db->get_all_user_uploaded_images($status);
			
			if(!empty($my_images))
			{
				$counter	=	0;
				
				foreach($my_images as $image)
				{	
					$res_id			=	$my_images[$counter][0];
					$res_image_name	=	$my_images[$counter][1];
					$res_colours	=	$my_images[$counter][2];
					$res_description=	$my_images[$counter][3];
					$res_image_type	=	$my_images[$counter][4];
					$res_keywords	=	$my_images[$counter][5];
					$res_posted_by	=	$my_images[$counter][6];
					$res_date		=	$my_images[$counter][7];
					$res_time		=	$my_images[$counter][8];
					$res_status		=	$my_images[$counter][9];
		?>
			<div class="img_display_thumb" style="display:inline-table;">
			<a href="/gallery/<?php echo $res_image_name; ?>" target="_blank"><img src="/gallery/<?php echo $res_image_name; ?>" class="img_thumb" /></a><br />
			<a href="<?php echo $_SERVER['PHP_SELF']."?del_id=".$res_id."&img=".$res_image_name."&posted=".$res_posted_by; ?>" class="link">Delete</a>
			<a href="/admin/edit-post.php?edt_id=<?php echo $res_id; ?>" class="link">Edit</a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?approve_id=".$res_id."&img=".$res_image_name; ?>" class="link">Approve</a>

			</div>
		<?php
					$counter++;
				}
			}
	?>
	</div>
		
		<div class="admin_image_container">	
			<div class="section_title">Approved Gallery Images</div>
			
				<?php
		
		$del_flag	=	0;
			if(isset($_GET['approve_del_id']) AND isset($_GET['img']) AND isset($_GET['posted']))
			{	
				$delete_id	=	$_GET['approve_del_id'];
				$image_name	=	$_GET['img'];
				$posted		=	$_GET['posted'];
				$db->admin_deleted_image($posted,$image_name);
				
				if($db->delete_current_image($delete_id))
				{
					$del_flag	=	1;
					header("Location:user-uploads.php");
				}
			
			}
			
			$my_images	=	array();
			
			$status		=	"Approved";
			
			$my_images	=	$db->get_all_user_uploaded_images($status);
			
			if(!empty($my_images))
			{
				$counter	=	0;
				
				foreach($my_images as $image)
				{	
					$res_id			=	$my_images[$counter][0];
					$res_image_name	=	$my_images[$counter][1];
					$res_colours	=	$my_images[$counter][2];
					$res_description=	$my_images[$counter][3];
					$res_image_type	=	$my_images[$counter][4];
					$res_keywords	=	$my_images[$counter][5];
					$res_posted_by	=	$my_images[$counter][6];
					$res_date		=	$my_images[$counter][7];
					$res_time		=	$my_images[$counter][8];
					$res_status		=	$my_images[$counter][9];
		?>
			<div class="img_display_thumb" style="display:inline-table;">
			<a href="/gallery/<?php echo $res_image_name; ?>" target="_blank"><img src="/gallery/<?php echo $res_image_name; ?>" class="img_thumb" /></a><br />
			<a href="<?php echo $_SERVER['PHP_SELF']."?approve_del_id=".$res_id."&img=".$res_image_name."&posted=".$res_posted_by; ?>" class="link">Delete</a>
			</div>
		<?php
					$counter++;
				}
			}
	?>
		</div>
	</div>
</body>
<?php
	require_once("../footer.php");
?>
