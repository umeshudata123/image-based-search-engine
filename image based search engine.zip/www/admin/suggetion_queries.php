<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	$admin_email_id	=	$_SESSION['current_login_admin'];

	if(!isset($_SESSION['current_login_admin']))
	{
		header("Location:/signin.php");
	}		
	
	$delete_id	=	"";
	$flag_success	=	0;
	if(isset($_GET['del_id']))
	{
		$delete_id	=	$_GET['del_id'];
		
		if($db->delete_suggetion($delete_id))
		{
			$flag_success	=	1;
		}
	}
?>
<html>
<head>
	<title>Suggetion Box</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
	<script src="/js/jquery-1.9.1.js" type="text/javascript"></script>
	<script src="/js/jquery-1.10.2.js" type="text/javascript"></script>
	
	<script>
	$(document).ready(function(){
	
		$(".delete_option").click(function(){
			
			 var confirm_result = confirm("Are you sure to delete this record?");
			 
			 if(confirm_result==false)
			 {
				return false;
			 }
		
		});
	});
	</script>
	
</head>
<body>

<?php 
	require_once('../header.php');
?>

<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	<?php
		require_once('admin_menus.php');
	?>
	<div class="page_head_titles">Users Suggetions</div>
	
	
	<?php
		if($flag_success==1)
		{
	?>
			<div>Record <?php echo $delete_id; ?> deleted successfully!</div>
	<?php
		}
	?>
	
	<table border="1" cellspacing="0" width="100%" class="report_tab">
		<thead>
			<td>Sr. No</td>
			<td>Sent From</td>
			<td>Suggetion</td>
			<td>Date</td>
			<td>Time</td>
			<!--<td>Delete</td>-->
			<td>Reply</td>
		</thead>
<?php	
	$user_suggestion_data	=	array();	
	$user_suggestion_data	=$db->show_user_suggetion($admin_email_id);
	
	if(!empty($user_suggestion_data))
	{
		$counter = 0;
		foreach($user_suggestion_data as $record)
		{
			$result_id			=	$user_suggestion_data[$counter][0];
			$result_sent_from	=	$user_suggestion_data[$counter][1];
			$result_suggestion	=	$user_suggestion_data[$counter][2];
			$result_date		=	$user_suggestion_data[$counter][3];
			$result_time		=	$user_suggestion_data[$counter][4];
		if($result_sent_from!="admin")
		{
	?>
		<tr style="<?php if($counter%2==0){ ?> background-color:#FAFAFA;<?php } ?>">
			<td><?php echo $counter+1; ?></td>
			<td><?php echo $result_sent_from; ?></td>
			<td><?php echo $result_suggestion; ?></td>
			<td><?php echo $result_date; ?></td>
			<td><?php echo $result_time; ?></td>
			<!--<td><a href="<?php echo $_SERVER['PHP_SELF']; ?>?del_id=<?php echo $result_id; ?>" class="delete_option">Delete</a></td>-->
			<td><a href="/admin/reply-to-suggetions.php?suggetion_id=<?php echo $result_id; ?>" target="_blank">Reply</a></td>
		</tr>
	<?php
			}
			$counter++;
		}
	}
	else
	{
	?>
		<tr>
			<td colspan="7">No suggetions availble</td>
		</tr>
	<?php	
	}
	?>
	
		</table>
</div>

<?php
	require_once('../footer.php');
?>


</body>
</html>