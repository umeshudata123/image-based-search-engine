<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	if(!isset($_SESSION['current_login_admin']))
	{
		header("Location:/signin.php");
	}
	
		$current_login_admin	=	$_SESSION['current_login_admin'];
	
		if(isset($_POST['form_submit_btn']))
		{
		
		$valid_formats = array("jpg", "png", "gif", "bmp","JPEG","JPG","BMP","PNG");
	
		if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name 				= 	$_FILES['photoimg']['name'];
			$size 				= 	$_FILES['photoimg']['size'];		
				if(strlen($name))
				{
					
					list($txt, $ext) = explode(".", $name);
					
					if(in_array($ext,$valid_formats))
					{
						$files	=	array();

						function generateRandomString($length = 10) {
							$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
							$charactersLength = strlen($characters);
							$randomString = '';
							for ($i = 0; $i < $length; $i++) 
							{
								$randomString .= $characters[rand(0, $charactersLength - 1)];
							}
							return $randomString;
						}
						
						$current_random_string = generateRandomString();
						
						$actual_image_name = date("Y-m-d").$current_random_string.".".strtolower($ext);				
				
						$tmp = $_FILES['photoimg']['tmp_name'];
						
						$img_Dir = "../blocked-images/";
						
						if(!file_exists($img_Dir))
						{
							mkdir($img_Dir);
						}
						
						if(move_uploaded_file($tmp, $img_Dir.$actual_image_name))
						{
							$db->save_blocked_image_file($actual_image_name);
						}
						else
						{
							echo "alert('failed');";
						}
					}
					else
					{
						echo "alert('Invalid file format..')";	
					}
				}
			else
			{
				echo "alert('Please select image..!')";
			}
		}
	}
?>
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	<?php
	require_once("../header.php");
	?>
	<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	
	<?php
		require_once('user_menus.php');
	?>
	<div class="page_head_titles">Blocked Image Gallery</div>
		
		<div class="form_container" style="width:auto;">
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
			
			<input type="file" name="photoimg" id="prof_image_uploader" class="upload-image" />
			
			<br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Update"/>
		</form>	
	</div>
	
	<div class="my_image_container">
	
		<?php
			$del_flag	=	0;
			if(isset($_GET['del_id']) AND isset($_GET['img']))
			{	
				$delete_id	=	$_GET['del_id'];
				$image_name	=	$_GET['img'];
				
				if($image_name!="")
				{
					unlink('../blocked-images/'.$image_name);
				}
				
				if($db->delete_current_blocked_image($delete_id))
				{
					$del_flag	=	1;
				}
			}
			
			if($del_flag==1)
			{
		?>
			<div class="success_msg"><?php echo $image_name; ?> - Image deleted successfully</div>
		<?php
			}
			
			
			$my_images	=	array();
			
			$my_images	=	$db->get_all_blocked_images();
			
			if(!empty($my_images))
			{
				$counter	=	0;
				
				foreach($my_images as $image)
				{	
					$res_id			=	$my_images[$counter][0];
					$res_image_name	=	$my_images[$counter][1];
		?>
			<div class="img_display_thumb" style="display:inline-table;">
				<a href="/blocked-images/<?php echo $res_image_name; ?>" target="_blank"><img src="/blocked-images/<?php echo $res_image_name; ?>" class="img_thumb" /></a><br />
				<a href="<?php echo $_SERVER['PHP_SELF']."?del_id=".$res_id."&img=".$res_image_name; ?>" class="link">Delete</a>
			</div>
		<?php
					$counter++;
				}
			}
		?>
	</div>
	
	</div>
</body>
<?php
	require_once("../footer.php");
?>
