<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	if(!isset($_SESSION['current_login_admin']))
	{
		header("Location:/admin/index.php");
	}
?>
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	<?php
	require_once("../header.php");
	?>
	<div id="middle_section" style="background-image:url('images/ADMIN-BANNER-1.png'); background-size:100% 100%;">
	
		<?php
		require_once('user_menus.php');
	?>
	</div>
</body>
<?php
	require_once("../footer.php");
?>
