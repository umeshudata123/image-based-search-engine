<?php
	require_once("../lib/functions.php");
	$db = new db_functions();
	
	$admin_email_id	=	$_SESSION['current_login_admin'];

	if(!isset($_SESSION['current_login_admin']))
	{
		header("Location:/signin.php");
	}		
	
	$flag_success	=	0;
	$suggetion_id	=	"";
	
	if(isset($_GET['suggetion_id']))
	{	
		$suggetion_id	=	$_GET['suggetion_id'];
		$_SESSION['current_suggestion_id']= $suggetion_id;
	}
	else if(isset($_SESSION['current_suggestion_id']))
	{
		$suggetion_id	=	$_SESSION['current_suggestion_id'];
	}
	
	$current_suggetion_data	=	array();
	$current_suggetion_data	=	$db->get_user_suggetion_by_id($suggetion_id);

	$sent_from	=	"";
	$message	=	"";
	
	if(!empty($current_suggetion_data))
	{
		$sent_from	=	$current_suggetion_data[0];
		$message	=	$current_suggetion_data[1];
	}
	
	
	$success_flag	=	0;
	if(isset($_POST['form_submit_btn']))
	{
		$reply_message	=	$_POST['admin_reply'];
		if($db->save_reply_message($suggetion_id,$sent_from,$reply_message))
		{
			$success_flag	=	1;
		}
	}
	
?>
<html>
<head>
	<title>Suggetion Box</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
	<script src="/js/jquery-1.9.1.js" type="text/javascript"></script>
	<script src="/js/jquery-1.10.2.js" type="text/javascript"></script>

</head>
<body>

<?php 
	require_once('../header.php');
?>

<div id="middle_section" style="background-image:url('../images/back1.jpg'); background-size:100% 100%;">
	<?php
		require_once('admin_menus.php');
	?>
	
	<div class="page_head_titles">Reply To Users Suggetion</div>
	
	
	<?php
		if($flag_success==1)
		{
	?>
			<div>Record <?php echo $delete_id; ?> deleted successfully!</div>
	<?php
		}
	?>
	<div class="form_container">
		<?php
			if($success_flag==1)
			{
		?>
			<div class="success_msg">Your reply successfully sent to user!</div>
		<?php
			}
		?>
		
		<div style="text-align:left;">
		Sent From : <?php echo $sent_from; ?><br />
		Message : <?php echo $message; ?>
		</div>		
		
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
			
			<textarea name="admin_reply" class="form_txtbx" placeholder="Enter your reply" style="height:200px;" required></textarea>

			</select>
			
			<br /><br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Submit"/>
		</form>
	</div>	
</div>

<?php
	require_once('../footer.php');
?>


</body>
</html>