<?php
	require_once("../lib/functions.php");
	$db = new db_functions();

	$password_error		=	"";
	$flag 				=	0;
	$admin_error		=	"";
	
	if(isset($_GET['lout_c_u']))
	{
		unset($_SESSION['current_login_admin']);
	}
	
	if(isset($_SESSION['current_login_admin']))
	{
		header("Location:/admin/dashboard.php");
	}
	
	if(isset($_POST['form_submit_btn']))
	{
		$userid		=	$_POST['user_id'];
		$password	=	$_POST['u_password'];
		
		$db_password	=	$db->check_admin_exist($userid);
		
		if($db_password!="")
		{
			if($db_password==$password)
			{
				$_SESSION['current_login_admin']	=	$userid;
				
				header("Location:/admin/dashboard.php");
			}
			else
			{
				$admin_error	=	"Incorrect password";
			}
		}
		else
		{
				$admin_error	=	"Invalid Credentials!";
		}
	}
?>

<html>
<head>
	<title>Log In</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	
<?php 
	require_once('../header.php');
?>

<div id="middle_section_1">

		<div class="page_head_titles">SignIn</div>

		<style>
		body{
			background-image: url("/images/websitebuilderbackground1.png");
			background-repeat:no-repeat;
			background-size:cover; 
		}
		</style>
	<div class="form_container_signin">
 			<?php
			if($admin_error!="")
			{
			?>
			<div class="success_msg" style="background-color:#FAFAFA; color:RED;">
				<?php echo $admin_error; ?>
			</div>	
			<?php	
			}	
			?>
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
			<input type="email" name="user_id" class="form_txtbx" placeholder="Enter UserId" required  />
			
			<input type="password" name="u_password" class="form_txtbx" placeholder="Enter password" required />
			<span class="error_indicator"><?php echo $password_error; ?></span>
			
			<br /><br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Log In"/>
		</form>
	</div>
</div>

<?php
	require_once('../footer.php');
?>


</body>
</html>
