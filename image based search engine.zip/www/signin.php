<?php
	require_once("lib/functions.php");
	$db = new db_functions();

	$error		=	"";
	$error_flag 				=	0;
	
	if(isset($_SESSION['current_login_user']))
	{
		header("Location:/user/dashboard.php");
	}
	
	if(isset($_GET['lout_c_u']))
	{
		unset($_SESSION['current_login_user']);
	}
	
	if(isset($_POST['form_submit_btn']))
	{
		$userid		=	$_POST['user_id'];
		$password	=	$_POST['u_password'];
		
		$db_password	=	$db->check_user_exist($userid);
		
		if($db_password!="")
		{
		//check if status pending
			$otp_status	=	$db->check_otp_status($userid);
			if($otp_status == 'Pending')
			{
				$_SESSION['current_otpid']	=	$userid;
				header("Location:otp-form.php");
			}
			else
			{
				if($db_password==$password)
				{
					$_SESSION['current_login_user']	=	$userid;
					
					header("Location:/user/dashboard.php");
				}
				else
				{
					$error= "Incorrect password";
					$erro_flag=1;
				}
			}
		}
		else
		{
			$error="This user is not registered with us!";
		}
		
	}
?>

<html>
<head>
	<title>Log In</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	
<?php 
	require_once('header.php');
?>
		



<div id="middle_section_1">

		<div class="page_head_titles">SignIn</div>

		<style>
		body{
			background-image: url("images/websitebuilderbackground1.png");
			background-repeat:no-repeat;

			background-size:cover; 
		}
		</style>
	<div class="form_container_signin">
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
 			
		<input type="email" name="user_id" class="form_txtbx" placeholder="Enter UserId" required  />
			
		<input type="password" name="u_password" class="form_txtbx" placeholder="Enter password" required />
		<span class="error_indicator"><?php echo $error; ?></span>

		<div class="forget_pass">
			<a href="/forget_pass.php"><font size=4px, color="white">Forgot Password?</font></a>
		</div>
			
		<br /><br />
		<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Log In"/>
		</form>
	</div>
</div>

<?php
	require_once('footer.php');
?>


</body>
</html>
