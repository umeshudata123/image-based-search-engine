<?php
	require_once("lib/functions.php");
	$db = new db_functions();
	
	$contact_num_error	=	"";
	$password_error		=	"";
	$conf_pwd_error		=	"";
	$flag 				=	0;
	$success_flag		=	0;
	$register_error		=	"";
	$gender_error	=	 "";
	
	$username	=	"";
	$contact_num=	"";
	$email_id	=	"";
	$dob		=	"";
	$gender		=	"";
	$password	=	"";
	$confpwd	=	"";
	
	if(isset($_POST['form_submit_btn']))
	{
		$username	=	$_POST['username'];
		$contact_num=	$_POST['contact_num'];
		$email_id	=	$_POST['user_email'];
		$dob		=	$_POST['user_dob'];
		$gender		=	$_POST['user_gender'];
		$password	=	$_POST['u_password'];
		$confpwd	=	$_POST['u_conf_password'];
		
		if($gender=="Select Gender")
		{
			$gender_error	=	"Please select gender";
			$flag 				=	1;
		}
		
		if(!is_Numeric($contact_num))
		{
			$contact_num_error	=	"Please enter numeric contact number";
			$flag 				=	1;
		}
		else if(strlen($contact_num)<10 OR strlen($contact_num)>10)
		{
			$contact_num_error	=	"Please enter 10 digit contact number";
			$flag 				=	1;
		}
		
		if(strlen($password)<4)
		{
			$password_error		=	"Please enter at least 4 characters";
			$flag 				=	1;
		}
		else if($password!=$confpwd)
		{
			$conf_pwd_error		=	"Please match the password";
			$flag 				=	1;
		}
		
		if($flag==0)
		{
			$user_exist	=	$db->check_user_exist($email_id);
			
			if($user_exist=="")
			{
				function generateRandomString($length = 5) {
				$characters = '0123456789';
				$charactersLength = strlen($characters);
				$randomString = '';
					for ($i = 0; $i < $length; $i++) 
					{
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
						return $randomString;
				}
						
				$otp_number = generateRandomString();
				$otp_status = "Pending";
				//Save to database
				if($db->register_new_user($username,$contact_num,$email_id,$dob,$gender,$password,$otp_number,$otp_status))
				{
				
					$to      = $email_id;
					$subject = 'OTP Number';
					$message = 'Your OTP NO is'.$otp_number;
					$headers = 'From: webmaster@example.com' . "\r\n" .
						'Reply-To: webmaster@example.com' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();

					mail($to, $subject, $message, $headers);
					$success_flag	=	1;
					
					$username	=	"";
					$contact_num=	"";
					$email_id	=	"";
					$dob		=	"";
					$gender		=	"";
					$password	=	"";
					$confpwd	=	"";
				}
			}
			else
			{
				$register_error		= "This user is already registered!";
			}
		}
	}
?>
<html>
<head>
	<title>Registration</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
	
</head>
<body>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
<?php 
	require_once('header.php');
?>

<div id="middle_section_1">

	<div class="page_head_titles">SignUp</div>
	<style>
		body{
			background-image: url("images/elegant-abstract-blue-backgrounds-ppt2.jpg");
			background-repeat:no-repeat;

			background-size:cover; 
		}
	</style>

	<div class="form_container">
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
			
			<?php
				if($success_flag==1)
				{
					echo "<font color=\"1BB22A\", size=5px>Registration successful!</font>";
				}
			?>
			
			<span class="error_indicator"><?php echo $register_error;?></span>
			<input type="text" name="username" class="form_txtbx" placeholder="Enter full name" required value="<?php echo $username; ?>"  />
			<input type="text" name="contact_num" class="form_txtbx" placeholder="Enter contact number" required  value="<?php echo $contact_num; ?>" />
			<span class="error_indicator"><?php echo $contact_num_error; ?></span>
			<input type="email" name="user_email" class="form_txtbx" placeholder="Enter email id" required  value="<?php echo $email_id; ?>" />
			<input type="text" id="datepicker" name="user_dob" class="form_txtbx" placeholder="Enter date of birth" required  value="<?php echo $dob; ?>" />
			<select name="user_gender" class="form_txtbx">
				<?php
					if($gender!="")
					{
				?>
				<option value="<?php echo $gender; ?>"><?php echo $gender; ?></option>
				<?php
					}
				?>
				<option value="Select Gender">Select Gender</option>
				<option value="Male">Male</option>
				<option value="Female">Female</option>
			</select>
			
			<span class="error_indicator"><?php echo $gender_error; ?></span>
			<input type="password" name="u_password" class="form_txtbx" placeholder="Enter password" required  value="<?php echo $password; ?>" />
			<span class="error_indicator"><?php echo $password_error; ?></span>
			<input type="password" name="u_conf_password" class="form_txtbx" placeholder="Enter confirm password" required  value="<?php echo $confpwd; ?>" />
			<span class="error_indicator"><?php echo $conf_pwd_error; ?></span>
			<br /><br />
			<input type="submit" name="form_submit_btn" class="form_submit_btn" />
		</form>
	</div>
</div>

<?php
	require_once('footer.php');
?>


</body>
</html>