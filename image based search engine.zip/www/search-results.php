<?php
	require_once("lib/functions.php");
	$db = new db_functions();
	
	error_reporting(0);
	ini_set('display_errors', 0);
	$value_name = "";
	$tmp_name = "";
	$search_query	=	"";
	$showDivFlag ="";
	$error_message_n = "";
	
	if(isset($_POST['search_btn']))
	{	
		$image_fetch	=	$_POST['image_fetch'];
		if($image_fetch == 'browse')
		{
			$valid_formats = array("jpg","png","gif","bmp","jpeg","JPEG","JPG","BMP","PNG","GIF");
		
			if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
			{	
				$name 				= 	$_FILES['photoimg']['name'];
				$size 				= 	$_FILES['photoimg']['size'];

				if(strlen($name))
					{				
						list($txt, $ext) = explode(".", $name);
						
						$value_name	=	$_FILES['photoimg']['tmp_name'];
						
						if(in_array($ext,$valid_formats))
						{
							$files	=	array();

							function generateRandomString($length = 10) {
								$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
								$charactersLength = strlen($characters);
								$randomString = '';
								for ($i = 0; $i < $length; $i++) 
								{
									$randomString .= $characters[rand(0, $charactersLength - 1)];
								}
								return $randomString;
							}
							
							$current_random_string = generateRandomString();
							
							$actual_image_name = $current_random_string.".".strtolower($ext);						
		
							$tmp = $_FILES['photoimg']['tmp_name'];
							
							$img_Dir = "tmp_image/";
							
							if(!file_exists($img_Dir))
							{
								mkdir($img_Dir);
							}
							
							if(move_uploaded_file($tmp,$img_Dir.$actual_image_name))
							{
								$value_name	= 'tmp_image/'.$actual_image_name;
							}
							else
							{
								$image_error	=	"failed" ;
								$flag				=	1;
							}	
						}
						else
						{
							$image_error	= "Invalid file format";
							$flag				=	1;	
						}	
					}	
			}
		}
		else if($image_fetch == 'take_photo')
		{
			if(isset($_SESSION['current_cap_img']))
			{
				$value_name	= 'uploads/thumbs/'.$_SESSION['current_cap_img'];
				$actual_image_name = $value_name;
			}
			else
			{
				$error_message_n = "You have not captured any image";
			}
		}
		$search_query	=	$_POST['search_box'];
		$search_criteria=	$_POST['search_criteria'];		
		
		$_SESSION['search_query']	=	$search_query;
		$_SESSION['search_criteria']	=	$search_criteria;
	}
	else if(isset($_SESSION['search_query']) AND isset($_SESSION['search_criteria']))
	{
		$search_query	=	$_SESSION['search_query'];
		$search_criteria=	$_SESSION['search_criteria'];
	}
	
?>
	
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body style="background-image:url('/images/back1.jpg'); background-size:100% 100%;">

	<div class="middle_section" style="min-height:600px; text-align:center;">
	<br />
	
	<div style="font-size:18px; text-align:left; margin-left:170px;">You Searched For : <label style="color:VOILET;"><?php echo $search_query; if($search_query==""){ echo "*"; } ?></label>
		<div class="colours_class">
		
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=brown"; ?>"><img src="/images/brown.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=black"; ?>"><img src="/images/black.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=gray"; ?>"><img src="/images/gray.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=pink"; ?>"><img src="/images/pink.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=purple"; ?>"><img src="/images/purple.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=turquoise"; ?>"><img src="/images/turquoise.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=yellow"; ?>"><img src="/images/yellow.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=orange"; ?>"><img src="/images/orange.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=white"; ?>"><img src="/images/white.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=blue"; ?>"><img src="/images/blue.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=green"; ?>"><img src="/images/green.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=red"; ?>"><img src="/images/red.jpg" class="color_img" /></a>
		</div>
	</div>
	<br />
	<?php
		echo "<label style='text-align:center; color:red;'>".$error_message_n."</label>";
		if($actual_image_name!="")
		{
	
			if($image_fetch == 'browse' AND $search_criteria=="image_based_search")//div that is shown in after search
			{
		?>
				<center><img id="image_temp" src="/tmp_image/<?php echo $actual_image_name; ?>" height="300" width="300" style="padding:5px;margin-top:60px;border:1px solid #cdcdcd;"></center><br />
		<?php
			}else if($image_fetch == 'take_photo' AND $search_criteria=="image_based_search" AND $value_name!="")
			{
		?>
				<center><img src="<?php echo $actual_image_name; ?>" height="300" width="300" style="padding:5px;margin-top:60px;border:1px solid #cdcdcd;"></center><br />
		<?php
			}
		
		}
	?>
	<br />
		<?php
			
			if($search_criteria=="text_based_search")
			{
			 
			$searched_images_data	=	array();
			
			if($search_type=='text_based_search')
			 {?>
				<style = "display :none">
			 <?php
			 }
			 else
			 {
				$showDivFlag=false;
			 }
			 
			 if($search_query=="")
			{
				echo "You have not enetered any search query";
			}
			else
			{
					if(isset($_GET['color']))
					{
						$cur_colour	=	$_GET['color'];
						$searched_images_data	=	$db->get_all_searched_images_for_colour($search_query,$cur_colour);
					}
					else
					{
						$searched_images_data	=	$db->get_all_searched_images($search_query);
					}
			}
			if(!empty($searched_images_data))
			{
				
				foreach($searched_images_data as $record)
				{
					$cur_id	=	$record;
					$count = 0;
					
					$d_data	=	array();
					$d_data	=	$db->get_current_d_data($cur_id);
					
					$res_id			=	$d_data[$count][0];
					$res_image_name	=	$d_data[$count][1];
					$res_colours	=	$d_data[$count][2];
					$res_description=	$d_data[$count][3];
					$res_image_type	=	$d_data[$count][4];
					$res_keywords	=	$d_data[$count][5];
					$res_posted_by	=	$d_data[$count][6];
					$res_date		=	$d_data[$count][7];
					$res_time		=	$d_data[$count][8];
					$res_status		=	$d_data[$count][9];
			?>
				<div class="img_display_thumb" style="display:inline-table;">
					<a href="/gallery/<?php echo $res_image_name; ?>" target="_blank"><img src="/gallery/<?php echo $res_image_name; ?>" class="img_thumb" /></a>
				</div>
		
			<?php
					$count++;
				}
			}
			else
			{
				echo "<center>No Search Result Found</center>";
			}
			
			}
			else if($search_criteria=="image_based_search" AND $value_name!="")
			{
				include_once __DIR__.'/GoogleImageSearch.php';
				
				$imageSearch = new GoogleImageSearch();
				
				if($value_name!="")
				{
					if($results = $imageSearch->search($value_name, 2)) {
						if($results['search_results']) {
							echo "<span style='color:RED;'>Best guess:</span> <strong><a target='_blank' href=\"{$results['best_guess'][1]}\">{$results['best_guess'][0]}</strong><br />\n";
							echo "<ol><br />\n";
							foreach($results['search_results'] as $k => $r) {
								echo "<li><a target='_blank' href=\"{$r[1]}\">{$r[0]}</a> ; \n";
							}
							echo "</ol><br />\n";
						} else {
							echo 'Nothing found';
						}

					}
				}
				else
				{
					echo "Please select file";
				}
			}
		?>
	</div>

	<?php
		unset($_SESSION['current_cap_img']);
		require_once('footer.php');
	?>
</body>
</html>