<?php
	require_once("lib/functions.php");
	$db = new db_functions();

	$error		=	"";
	$error_flag 				=	0;
	$success_flag = 0;
	if(isset($_SESSION['current_login_user']))
	{
		header("Location:/user/dashboard.php");
	}
	if(isset($_SESSION['current_otpid']))
	{
		$userid = $_SESSION['current_otpid'];
	}
	if(isset($_POST['form_submit_btn']))
	{
		$otp_no		=	$_POST['otp_no'];
		$db_otpno=$db->check_otp_number($userid);
		if($otp_no == $db_otpno)
		{
			$db->update_otp_status($userid);
			$success_flag = 1;
			//header("Location:signin.php");
		}
		else
		{
			$error="Correct OTP Number.";
		}
		
	}
?>

<html>
<head>
	<title>OTP Verification</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>
	
<?php 
	require_once('header.php');
?>
		



<div id="middle_section_1">

		<div class="page_head_titles">OTP Verification</div>

		<style>
		body{
			background-image: url("images/websitebuilderbackground1.png");
			background-repeat:no-repeat;

			background-size:cover; 
		}
		</style>
	<div class="form_container_signin">
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
 		<?php
				if($success_flag==1)
				{
					echo "<font color=\"e0350b\", size=5px>OTP No Verified Successfully.</font>";
				}
			?>
		
		<input type="text" name="otp_no" class="form_txtbx" placeholder="Enter OTP No." required />
		<span class="error_indicator"><?php echo $error; ?></span>

		<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Submit"/>
		</form>
	</div>
</div>

<?php
	require_once('footer.php');
?>


</body>
</html>
