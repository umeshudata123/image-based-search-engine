<link href="/images/iconsearch.jpg" rel="shortcut icon" />
<div class="header">
	<div class="header_mid_container">
		<a href="/index.php" class="site_name">Web Image Search</a>
		
		<div class="menu_container">
			<a href="/" class="menu">Home</a>
			<?php
				if(!isset($_SESSION['current_login_user']) and !isset($_SESSION['current_login_admin']))
				{
			?>
				<a href="/signup.php" class="menu">Sign Up</a>
				<a href="/signin.php" class="menu">Sign In</a>
			<?php
				}
				
				elseif(isset($_SESSION['current_login_user']))
				{
			?>
				<a href="/user/dashboard.php" class="menu">My Dashboard</a>
			<?php
				}
			
				else 
				{
			?>
				<a href="/admin/dashboard.php" class="menu">My Dashboard</a>
			<?php
				}
				?>
			<a href="/about_us.php" class="menu">About Us</a>
			<a href="/contact_us.php" class="menu">Contact Us</a>
		</div>
	</div>
</div>