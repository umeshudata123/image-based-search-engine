<?php
	session_start();
	
	class db_functions
	{
		private $con;
		
		function __construct()
		{
			$this->con	=	new mysqli("localhost","root","","web_image_search");
		}	
		
		function register_new_user($username,$contact_num,$email_id,$dob,$gender,$password)
		{
			$date	=	date("Y-m-d");
			$time	=	date("H:i:s");
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `applications_users`(`user_name`, `contact_number`, `email_id`, `date_of_birth`, `gender`, `password`, `date`, `time`) VALUES (?,?,?,?,?,?,?,?)"))
			{
				$stmt_insert->bind_param("ssssssss",$username,$contact_num,$email_id,$dob,$gender,$password,$date,$time);
				
				if($stmt_insert->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function update_user_data($username,$contact_num,$email_id,$dob,$gender)
		{
			if($stmt_update = $this->con->prepare("UPDATE `applications_users` SET `user_name`=?,`contact_number`=?,`date_of_birth`=?,`gender`=? WHERE `email_id`=?"))
			{
				$stmt_update->bind_param("sssss",$username,$contact_num,$dob,$gender,$email_id);
				
				if($stmt_update->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function change_password($password,$email_id)
		{
			if($stmt_update = $this->con->prepare("UPDATE `applications_users` SET `password`=? WHERE `email_id`=?"))
			{
				$stmt_update->bind_param("ss",$password,$email_id);
				
				if($stmt_update->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		function change_admin_password($password,$email_id)
		{
			if($stmt_update = $this->con->prepare("UPDATE `admin` SET `password`=? WHERE `user_id`=?"))
			{
				$stmt_update->bind_param("ss",$password,$email_id);
				
				if($stmt_update->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function check_user_exist($email_id)
		{
			if($stmt_select = $this->con->prepare("Select `password` from `applications_users` where `email_id` = ?"))
			{
				$stmt_select->bind_param("s",$email_id);
				
				$stmt_select->bind_result($result_password);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_password;
					}
					return false;
				}
			}
		}
		
		
		function check_admin_exist($email_id)
		{
			if($stmt_select = $this->con->prepare("Select `password` from `admin` where `user_id` = ?"))
			{
				$stmt_select->bind_param("s",$email_id);
				
				$stmt_select->bind_result($result_password);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_password;
					}
					return false;
				}
			}
		}
		
		function fetch_data($email_id)
		{
			if($stmt_select = $this->con->prepare("Select `id`, `user_name`, `contact_number`, `email_id`, `date_of_birth`, `gender`, `password` from `applications_users` where `email_id` = ?"))
			{
				$stmt_select->bind_param("s",$email_id);
				
				$stmt_select->bind_result($res_id,$username,$contact_num,$email_id,$dob,$gender,$password);
				
				if($stmt_select->execute())
				{
					$data	=	array();
					
					if($stmt_select->fetch())
					{
						$data[0]	=	$res_id;
						$data[1]	=	$username;
						$data[2]	=	$contact_num;
						$data[3]	=	$email_id;
						$data[4]	=	$dob;
						$data[5]	=	$gender;
						$data[6]	=	$password;
						
						return $data;
					}
					return false;
				}
			}
		}
		
		
		function check_interest_exist($current_user)
		{
			if($stmt_select = $this->con->prepare("Select `interest_of` from `user_interests` where `interest_of` = ?"))
			{
				$stmt_select->bind_param("s",$current_user);
				
				$stmt_select->bind_result($result_interest_of);
				
				if($stmt_select->execute())
				{
					if($stmt_select->fetch())
					{
						return $result_interest_of;
					}
					return false;
				}
			}
		}
		
		function save_user_interest($current_user,$interests,$image_type,$image_color,$image_resol)
		{
			$date	=	date("Y-m-d");
			$time	=	date("H:i:s A");

			if($stmt_insert = $this->con->prepare("INSERT INTO `user_interests`(`interest_of`, `keywords`, `image_type`, `color`, `size`, `date`, `time`) VALUES (?,?,?,?,?,?,?)"))
			{
				$stmt_insert->bind_param("sssssss",$current_user,$interests,$image_type,$image_color,$image_resol,$date,$time);
				
				if($stmt_insert->execute())
				{
				echo 99;
					return true;
				}
				return false;
			}
		}
		
		function update_user_interests($current_user,$interests,$image_type,$image_color,$image_resol)
		{
			$date	=	date("Y-m-d");
			$time	=	date("H:i:s A");
			
			if($stmt_update = $this->con->prepare("UPDATE `user_interests` SET `keywords`=?,`image_type`=?,`color`=?,`size`=?,`date`=?,`time`=? WHERE `interest_of` = ?"))
			{
				$stmt_update->bind_param("sssssss",$interests,$image_type,$image_color,$image_resol,$date,$time,$current_user);
				
				if($stmt_update->execute())
				{
					return true;
				}
				return false;
			}
		}
		
		function get_user_interest($current_user)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `interest_of`, `keywords`, `image_type`, `color`, `size`, `date`, `time` FROM `user_interests` WHERE `interest_of` = ?"))
			{
				$stmt_select->bind_param("s",$current_user);
				
				$stmt_select->bind_result($result_id, $result_interest_of, $result_keywords, $result_image_type, $result_color, $result_size, $result_date, $result_time);
				
				if($stmt_select->execute())
				{
					$result_data	=	array();
					
					if($stmt_select->fetch())
					{
						$result_data[0]	=	$result_id;
						$result_data[1]	=	$result_interest_of;
						$result_data[2]	=	$result_keywords;
						$result_data[3]	=	$result_image_type;
						$result_data[4]	=	$result_color;
						$result_data[5]	=	$result_size;
						$result_data[6]	=	$result_date;
						$result_data[7]	=	$result_time;
						
						return $result_data;
					}
					return false;
				}
			}
		}
		function show_user_suggetion($admin_email_id)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `sent_from`, `suggetion_message`, `date`, `time` FROM `suggetion_box` ORDER BY `id` DESC"))
			{
				$stmt_select->bind_result($result_id, $result_sent_from, $result_suggestion, $result_date, $result_time);
				
				if($stmt_select->execute())
				{
					$result_data	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$result_data[$counter][0]	=	$result_id;
						$result_data[$counter][1]	=	$result_sent_from;
						$result_data[$counter][2]	=	$result_suggestion;
						$result_data[$counter][3]	=	$result_date;
						$result_data[$counter][4]	=	$result_time;
						
						$counter++;
					}
					if(!empty($result_data))
					{
						return $result_data;
					}
					else
					{
						return false;
					}	
				}
			}
		}
		function save_user_suggetion($users_email_id,$suggetion_message)
		{
			$date	=	date("Y-m-d");
			$time	=	date("H:i:s A");
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `suggetion_box`(`sent_from`, `suggetion_message`, `date`, `time`) VALUES (?,?,?,?)"))
			{
				$stmt_insert->bind_param("ssss",$users_email_id,$suggetion_message,$date,$time);
				
				if($stmt_insert->execute())
				{
					return true;
				}
				return false;
			}
		}
		
		function delete_suggetion($delete_id)
		{
			if($stmt_delete = $this->con->prepare("Delete from `suggetion_box` where `id` = ?"))
			{
				$stmt_delete->bind_param("i",$delete_id);
				
				if($stmt_delete->execute())
				{
					return true;
				}
				return false;
			}
		}
		
		function get_user_suggetion_by_id($suggetion_id)
		{
			if($stmt_select = $this->con->prepare("Select `sent_from`,`suggetion_message` from `suggetion_box` where `id` = ?"))
			{
				$stmt_select->bind_param("i",$suggetion_id);
				
				$stmt_select->bind_result($result_sent_from,$result_message);
				
				if($stmt_select->execute())
				{
					$data	=	array();
					if($stmt_select->fetch())
					{
						$data[0]	=	$result_sent_from;
						$data[1]	=	$result_message;
						
						return $data;
					}
					return false;
				}
			}
		}
		function save_reply_message($suggetion_id,$sent_to,$reply_message)
		{
			$date	=	date("Y-m-d");
			$time	=	date("H:i:s");
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `suggetion_box`(`sent_from`
			, `sent_to`,`suggetion_message`, `reply_to`, `date`, `time`) VALUES (?,?,?,?,?,?)"))
			{
				$sent_from="admin";
				$stmt_insert->bind_param("sssiss",$sent_from,$sent_to,$reply_message,$suggetion_id,$date,$time);
				if($stmt_insert->execute())
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		
		function show_message_list($email_id)
		{
			if($stmt_select	= $this->con->prepare("SELECT `id`,`sent_from`,`sent_to`,`suggetion_message`,
			`reply_to`,`date`,`time` FROM `suggetion_box` WHERE `sent_from`=? or sent_to=? ORDER BY `id` DESC"))
			{
				$stmt_select->bind_param("ss",$email_id,$email_id);
				$stmt_select->bind_result($result_id,$result_sent_from,$result_sent_to,$result_message,$result_reply_to,$result_date,$result_time);
			
				if($stmt_select->execute())
				{
					$result_data	=	array();
					$counter = 0;
					while($stmt_select->fetch())
					{
						$result_data[$counter][0]	=	$result_id;
						$result_data[$counter][1]	=	$result_sent_from;
						$result_data[$counter][2]	=	$result_sent_to;
						$result_data[$counter][3]   =	$result_message;
						$result_data[$counter][4]   =	$result_reply_to;
	
						$result_data[$counter][5]	=	$result_date;
						$result_data[$counter][6]	=	$result_time;
						$counter++;
					}
					if(!empty($result_data))
					{
						return $result_data;
					}
					else
					{
						return false;
					}	
				
				}
			}	
		}
		
		function save_my_uploaded_file($actual_image_name,$colours,$description,$keywords,$type,$current_login_user,$red,$orange,$yellow,$green,$turquoise,$blue,$purple,$pink,$white,$gray,$black,$brown)
		{
			$now_date	=	date("Y-m-d");
			$now_time	=	date("H:i:s A");
			
			if($current_login_user=="admin@wis.com")
			{
				$status		=	"Approved";
			}	
			else{
				$status		=	"Pending";
			}
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `gallery`(`image_name`, `colours`, `description`, `keywords`, `image_type`, `posted_by`, `date`, `time`, `status`, `red`, `orange`, `yellow`, `green`, `turquoise`, `blue`, `purple`, `pink`, `white`, `gray`, `black`, `brown`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"))
			{
				$stmt_insert->bind_param("sssssssssssssssssssss",$actual_image_name,$colours,$description,$keywords,$type,$current_login_user,$now_date,$now_time,$status,$red,$orange,$yellow,$green,$turquoise,$blue,$purple,$pink,$white,$gray,$black,$brown);
				
				if($stmt_insert->execute())
				{
					return true;
				}
				return false;
			}
		}
		
		function get_all_my_uploaded_images($current_login_user)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `posted_by`, `date`, `time`, `status` FROM `gallery` WHERE `posted_by` = ? ORDER By `id` DESC"))
			{
				$stmt_select->bind_param("s",$current_login_user);
				
				$stmt_select->bind_result($res_id,$res_image_name,$res_colours,$res_description,$res_image_type,$res_keywords,$res_posted_by,$res_date,$res_time,$res_status);
				
				if($stmt_select->execute())
				{
					$image_data	=	array();
					$counter	=	0;
					while($stmt_select->fetch())
					{
						$image_data[$counter][0]	=	$res_id;
						$image_data[$counter][1]	=	$res_image_name;
						$image_data[$counter][2]	=	$res_colours;
						$image_data[$counter][3]	=	$res_description;
						$image_data[$counter][4]	=	$res_image_type;
						$image_data[$counter][5]	=	$res_keywords;
						$image_data[$counter][6]	=	$res_posted_by;
						$image_data[$counter][7]	=	$res_date;
						$image_data[$counter][8]	=	$res_time;
						$image_data[$counter][9]	=	$res_status;
						
						$counter++;
					}
					if(!empty($image_data))
					{
						return $image_data;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function get_all_my_uploaded_images_by_id_wise($current_post_id)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `posted_by`, `date`, `time`, `status` FROM `gallery` WHERE `id` = ?"))
			{
				$stmt_select->bind_param("i",$current_post_id);
				
				$stmt_select->bind_result($res_id,$res_image_name,$res_colours,$res_description,$res_image_type,$res_keywords,$res_posted_by,$res_date,$res_time,$res_status);
				
				if($stmt_select->execute())
				{
					$image_data	=	array();
					$counter	=	0;
					while($stmt_select->fetch())
					{
						$image_data[$counter][0]	=	$res_id;
						$image_data[$counter][1]	=	$res_image_name;
						$image_data[$counter][2]	=	$res_colours;
						$image_data[$counter][3]	=	$res_description;
						$image_data[$counter][4]	=	$res_image_type;
						$image_data[$counter][5]	=	$res_keywords;
						$image_data[$counter][6]	=	$res_posted_by;
						$image_data[$counter][7]	=	$res_date;
						$image_data[$counter][8]	=	$res_time;
						$image_data[$counter][9]	=	$res_status;
						
						$counter++;
					}
					if(!empty($image_data))
					{
						return $image_data;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function update_my_image_details_admin($colours,$description,$keywords,$type,$cur_post_id)
		{
			$date	=	date("Y-m-d");
			$time	=	date("H:i:s A");
			
			if($stmt_update = $this->con->prepare("UPDATE `gallery` SET `colours`=?,`description`=?,`image_type`=?,`keywords`=? WHERE `id` = ?"))
			{
				$stmt_update->bind_param("ssssi",$colours,$description,$type,$keywords,$cur_post_id);
				
				if($stmt_update->execute())
				{
					return true;
				}
				return false;
			}
		}
		
		function get_all_blocked_images()
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `blocked_image_name` FROM `blocked_images` ORDER By `id` DESC"))
			{	
				$stmt_select->bind_result($res_id,$res_blocked_image);
				
				if($stmt_select->execute())
				{
					$image_data	=	array();
					$counter	=	0;
					while($stmt_select->fetch())
					{
						$image_data[$counter][0]	=	$res_id;
						$image_data[$counter][1]	=	$res_blocked_image;
						
						$counter++;
					}
					if(!empty($image_data))
					{
						return $image_data;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function get_all_user_uploaded_images($status)
		{
			if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `posted_by`, `date`, `time`, `status` FROM `gallery` WHERE `status` = ? ORDER By `id` DESC"))
			{
				$stmt_select->bind_param("s",$status);
				
				$stmt_select->bind_result($res_id,$res_image_name,$res_colours,$res_description,$res_image_type,$res_keywords,$res_posted_by,$res_date,$res_time,$res_status);
				
				if($stmt_select->execute())
				{
					$image_data	=	array();
					$counter	=	0;
					while($stmt_select->fetch())
					{
						$image_data[$counter][0]	=	$res_id;
						$image_data[$counter][1]	=	$res_image_name;
						$image_data[$counter][2]	=	$res_colours;
						$image_data[$counter][3]	=	$res_description;
						$image_data[$counter][4]	=	$res_image_type;
						$image_data[$counter][5]	=	$res_keywords;
						$image_data[$counter][6]	=	$res_posted_by;
						$image_data[$counter][7]	=	$res_date;
						$image_data[$counter][8]	=	$res_time;
						$image_data[$counter][9]	=	$res_status;
						
						$counter++;
					}
					if(!empty($image_data))
					{
						return $image_data;
					}
					else
					{
						return false;
					}
				}
			}
		}
		
		function delete_current_image($delete_id)
		{
			if($stmt_delete = $this->con->prepare("Delete from `gallery` where `id` = ?"))
			{
				$stmt_delete->bind_param("i",$delete_id);
				
				if($stmt_delete->execute())
				{
					return true;
				}
				return false;
			}
		}
		
		function delete_current_blocked_image($delete_id)
		{
			if($stmt_delete = $this->con->prepare("Delete from `blocked_images` where `id` = ?"))
			{
				$stmt_delete->bind_param("i",$delete_id);
				
				if($stmt_delete->execute())
				{
					return true;
				}
				return false;
			}
		}
		
		function approve_user_image($approve_id)
		{
			if($stmt_update = $this->con->prepare("Update `gallery` SET status = 'Approved' where `id` = ?"))
			{
				$stmt_update->bind_param("i",$approve_id);
				
				if($stmt_update->execute())
				{
					return true;
				}
				return false;
			}
		}
		
		function save_blocked_image_file($actual_image_name)
		{
			$now_date	=	date("Y-m-d");
			$now_time	=	date("H:i:s A");
			
			if($stmt_insert = $this->con->prepare("INSERT INTO `blocked_images`(`blocked_image_name`, `date`, `time`) VALUES (?,?,?)"))
			{
				$stmt_insert->bind_param("sss",$actual_image_name,$now_date,$now_time);
				
				if($stmt_insert->execute())
				{
					return true;
				}
				return false;
			}
		}
		
	function get_all_spam_images()
	{
		if($stmt_select = $this->con->prepare("Select `id`,`blocked_image_name` from `blocked_images`"))
		{
			$stmt_select->bind_result($id,$image_name);
			
			if($stmt_select->execute())
			{
				$data = array();
				
				$count = 0;
				
				while($stmt_select->fetch())
				{
					$data[$count][0] = $id;
					$data[$count][1] = $image_name;
					
					$count++;
				}
				if(!empty($data))
				{
					return $data;
				}
				else
				{
					return false;
				}
			}
		}	
	}
	
	function get_all_searched_images($search_query)
	{
		$search_array = explode(" ",$search_query);
		
		$search_string	=	"";
		$countr = 0;
		
		if(!empty($search_array))
		{
			$my_count = 0;
			foreach($search_array as $record)
			{
				if($search_string=="")
				{
					$search_string	=	"'".$search_array[$my_count]."'";
				}
				else
				{
					$search_string	=	$search_string.",'".$search_array[$my_count]."'";
				}
				$my_count++;
			}
		}
		
		if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `posted_by`, `date`, `time`, `status` FROM `gallery` WHERE `image_name` IN ($search_string) OR `colours` IN ($search_string) OR `description` IN ($search_string) OR `image_type` IN ($search_string) OR `keywords` IN ($search_string) OR `keywords` LIKE '%$search_query%' OR `image_name` LIKE '%$search_query%' OR `colours` LIKE '%$search_query%' OR `description` LIKE '%$search_query%' OR `image_type` LIKE '%$search_query%' ORDER By `id` DESC"))
		{
			$stmt_select->bind_result($res_id,$res_image_name,$res_colours,$res_description,$res_image_type,$res_keywords,$res_posted_by,$res_date,$res_time,$res_status);
			
			if($stmt_select->execute())
			{
				$image_data	=	array();
				$counter	=	0;

				while($stmt_select->fetch())
				{
					$image_data[$counter][0]	=	$res_id;
					$image_data[$counter][1]	=	$res_image_name;
					$image_data[$counter][2]	=	$res_colours;
					$image_data[$counter][3]	=	$res_description;
					$image_data[$counter][4]	=	$res_image_type;
					$image_data[$counter][5]	=	$res_keywords;
					$image_data[$counter][6]	=	$res_posted_by;
					$image_data[$counter][7]	=	$res_date;
					$image_data[$counter][8]	=	$res_time;
					$image_data[$counter][9]	=	$res_status;
					
					$counter++;
				}
				if(!empty($image_data))
				{
					return $image_data;
				}
				else
				{
					return false;
				}
			}
		}
	}
	
	function get_all_searched_images_for_colour($search_query,$cur_colour)
	{
		$search_array = explode(" ",$search_query);
		
		$search_string	=	"";
		$countr = 0;
		
		if(!empty($search_array))
		{
			$my_count = 0;
			foreach($search_array as $record)
			{
				if($search_string=="")
				{
					$search_string	=	"'".$search_array[$my_count]."'";
				}
				else
				{
					$search_string	=	$search_string.",'".$search_array[$my_count]."'";
				}
				$my_count++;
			}
		}
		
		if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `posted_by`, `date`, `time`, `status` FROM `gallery` WHERE `image_name` IN ($search_string) OR `colours` IN ($search_string) OR `description` IN ($search_string) OR `image_type` IN ($search_string) OR `keywords` IN ($search_string) OR `keywords` LIKE '%$search_query%' OR `image_name` LIKE '%$search_query%' OR `colours` LIKE '%$search_query%' OR `description` LIKE '%$search_query%' OR `image_type` LIKE '%$search_query%' ORDER By `$cur_colour` DESC"))
		{
			$stmt_select->bind_result($res_id,$res_image_name,$res_colours,$res_description,$res_image_type,$res_keywords,$res_posted_by,$res_date,$res_time,$res_status);
			
			if($stmt_select->execute())
			{
				$image_data	=	array();
				$counter	=	0;

				while($stmt_select->fetch())
				{
					$image_data[$counter][0]	=	$res_id;
					$image_data[$counter][1]	=	$res_image_name;
					$image_data[$counter][2]	=	$res_colours;
					$image_data[$counter][3]	=	$res_description;
					$image_data[$counter][4]	=	$res_image_type;
					$image_data[$counter][5]	=	$res_keywords;
					$image_data[$counter][6]	=	$res_posted_by;
					$image_data[$counter][7]	=	$res_date;
					$image_data[$counter][8]	=	$res_time;
					$image_data[$counter][9]	=	$res_status;
					
					$counter++;
				}
				if(!empty($image_data))
				{
					return $image_data;
				}
				else
				{
					return false;
				}
			}
		}
	}

	function get_all_current_user_interests($users_session_email)
	{
		if($stmt_select = $this->con->prepare("Select `keywords`,`image_type`,`color`,`size` from `user_interests` where `interest_of` = ?"))
		{
			$stmt_select->bind_param("s",$users_session_email);
			
			$stmt_select->bind_result($keywords,$image_type,$color,$size);
			
			if($stmt_select->execute())
			{
				$data = array();
				
				$count = 0;
				
				while($stmt_select->fetch())
				{
					$data[$count][0] = $keywords;
					$data[$count][1] = $image_type;
					$data[$count][2] = $color;
					$data[$count][3] = $size;
					
					$count++;
				}
				if(!empty($data))
				{
					return $data;
				}
				else
				{
					return false;
				}
			}
		}
	}
	function get_current_d_data($r_id)
	{
		if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `posted_by`, `date`, `time`, `status` FROM `gallery` WHERE `id` = '$r_id'"))
		{
			$stmt_select->bind_result($res_id,$res_image_name,$res_colours,$res_description,$res_image_type,$res_keywords,$res_posted_by,$res_date,$res_time,$res_status);
			
			if($stmt_select->execute())
			{
				$image_data	=	array();
				$counter	=	0;

				while($stmt_select->fetch())
				{
					$image_data[$counter][0]	=	$res_id;
					$image_data[$counter][1]	=	$res_image_name;
					$image_data[$counter][2]	=	$res_colours;
					$image_data[$counter][3]	=	$res_description;
					$image_data[$counter][4]	=	$res_image_type;
					$image_data[$counter][5]	=	$res_keywords;
					$image_data[$counter][6]	=	$res_posted_by;
					$image_data[$counter][7]	=	$res_date;
					$image_data[$counter][8]	=	$res_time;
					$image_data[$counter][9]	=	$res_status;
					
					$counter++;
				}
				if(!empty($image_data))
				{
					return $image_data;
				}
				else
				{
					return false;
				}
			}
		}	
	}
	function get_all_searched_images1($search_query)
	{
		$search_array = explode(" ",$search_query);
		
		$search_string	=	"";
		$countr = 0;
		
		/*if(!empty($search_array))
		{
			$my_count = 0;
			foreach($search_array as $record)
			{
				if($search_string=="")
				{
					$search_string	=	"'".$search_array[$my_count]."'";
				}
				else
				{
					$search_string	=	$search_string.",'".$search_array[$my_count]."'";
				}
				$my_count++;
			}
		}*/

		$image_data	=	array();
		$counter	=	0;
					
		foreach($search_array as $record)
		{
			$search_query	=	$record;
			if($stmt_select = $this->con->prepare("SELECT `id`, `image_name`, `colours`, `description`, `image_type`, `keywords`, `posted_by`, `date`, `time`, `status` FROM `gallery` WHERE `keywords` LIKE '%$search_query%' OR `image_name` LIKE '%$search_query%' OR `colours` LIKE '%$search_query%' OR `description` LIKE '%$search_query%' OR `image_type` LIKE '%$search_query%' ORDER By `id` DESC"))
			{
				$stmt_select->bind_result($res_id,$res_image_name,$res_colours,$res_description,$res_image_type,$res_keywords,$res_posted_by,$res_date,$res_time,$res_status);
				
				if($stmt_select->execute())
				{
					while($stmt_select->fetch())
					{
						/*if(!in_array($res_id,$image_data))
						{*/
						$image_data[$counter]	=	$res_id;
						/*$image_data[$counter][0]	=	$res_id;
						$image_data[$counter][1]	=	$res_image_name;
						$image_data[$counter][2]	=	$res_colours;
						$image_data[$counter][3]	=	$res_description;
						$image_data[$counter][4]	=	$res_image_type;
						$image_data[$counter][5]	=	$res_keywords;
						$image_data[$counter][6]	=	$res_posted_by;
						$image_data[$counter][7]	=	$res_date;
						$image_data[$counter][8]	=	$res_time;
						$image_data[$counter][9]	=	$res_status;*/
						
						$counter++;
						//}
					}
				}
			}
		}
			
			if(!empty($image_data))
			{
				//print_r($image_data);
				$image_data = array_unique($image_data);
				return $image_data;
			}
			else
			{
				return false;
			}
	}
}
?>