<?php
	require_once("lib/functions.php");
	$db = new db_functions();
?>
<html>
<head>
	<title>Contact Us</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body>

<?php 
	require_once('header.php');
?>

	<div class="middle_section" style="min-height:560px; background-image:url('../images/back1.jpg'); background-size:100% 100%;">
		<div class="page_head_titles">Contact Us</div>
		
		<br /><br /><br />

		<iframe src="" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
		
	</div>

<?php
	require_once('footer.php');
?>


</body>
</html>