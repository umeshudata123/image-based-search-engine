<?php

?>

<html>
<title>Log In</title>
	
	
<body>
	

		



<div id="middle_section_1">

		<div class="page_head_titles">SignIn</div>


	
		<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
 			
		
		<input type="email" name="user_id" class="form_txtbx" placeholder="Enter UserId" required  />
			
		<input type="password" name="u_password" class="form_txtbx" placeholder="Enter password" required />
		

		
			
		<br /><br />
		<input type="submit" name="form_submit_btn" class="form_submit_btn" value="Log In"/>
		</form>
	
</div>
</body>
</html>