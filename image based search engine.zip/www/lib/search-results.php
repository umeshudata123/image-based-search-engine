<?php
	require_once("lib/functions.php");
	$db = new db_functions();
	
	error_reporting(0);
	ini_set('display_errors', 0);
	
	$search_query	=	"";
	
	if(isset($_POST['search_btn']))
	{
		$search_query	=	$_POST['search_box'];
		$search_criteria=	$_POST['search_criteria'];		
		
		$_SESSION['search_query']	=	$search_query;
		$_SESSION['search_criteria']	=	$search_criteria;
	}
	else if(isset($_SESSION['search_query']) AND isset($_SESSION['search_criteria']))
	{
		$search_query	=	$_SESSION['search_query'];
		$search_criteria=	$_SESSION['search_criteria'];
	}
	
?>	
<html>
<head>
	<title>Web Image Search</title>
	
	<link rel="stylesheet" type="text/css" href="/css/stylesheet.css" />
</head>
<body style="background-image:url('/images/back1.jpg'); background-size:100% 100%;">

	<div class="middle_section" style="min-height:600px; text-align:center;">
	<br />
	
	<div style="font-size:18px; text-align:left; margin-left:170px;">You Searched For : <label style="color:VOILET;"><?php echo $search_query; if($search_query==""){ echo "*"; } ?></label>
		<div class="colours_class">
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=brown"; ?>"><img src="/images/brown.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=black"; ?>"><img src="/images/black.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=gray"; ?>"><img src="/images/gray.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=pink"; ?>"><img src="/images/pink.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=purple"; ?>"><img src="/images/purple.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=turquoise"; ?>"><img src="/images/turquoise.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=yellow"; ?>"><img src="/images/yellow.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=orange"; ?>"><img src="/images/orange.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=white"; ?>"><img src="/images/white.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=blue"; ?>"><img src="/images/blue.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=green"; ?>"><img src="/images/green.jpg" class="color_img" /></a>
			<a href="<?php echo $_SERVER['PHP_SELF']."?color=red"; ?>"><img src="/images/red.jpg" class="color_img" /></a>
		</div>
	</div>
	<br />
		<?php
			
			if($search_criteria=="text_based_search")
			{
			
			$searched_images_data	=	array();
			echo $search_query;
			if($search_query=="")
			{
				echo "You have not enetered any search query";
			}
			else
			{
				if(isset($_GET['color']))
				{
					$cur_colour	=	$_GET['color'];
					$searched_images_data	=	$db->get_all_searched_images_for_colour($search_query,$cur_colour);
				}
				else
				{
					$searched_images_data	=	$db->get_all_searched_images($search_query);
				}
			}
			if(!empty($searched_images_data))
			{
				
				foreach($searched_images_data as $record)
				{
					$cur_id	=	$record;
					$count = 0;
					
					$d_data	=	array();
					$d_data	=	$db->get_current_d_data($cur_id);
					
					$res_id			=	$d_data[$count][0];
					$res_image_name	=	$d_data[$count][1];
					$res_colours	=	$d_data[$count][2];
					$res_description=	$d_data[$count][3];
					$res_image_type	=	$d_data[$count][4];
					$res_keywords	=	$d_data[$count][5];
					$res_posted_by	=	$d_data[$count][6];
					$res_date		=	$d_data[$count][7];
					$res_time		=	$d_data[$count][8];
					$res_status		=	$d_data[$count][9];
			?>
				<div class="img_display_thumb" style="display:inline-table;">
					<a href="/gallery/<?php echo $res_image_name; ?>" target="_blank"><img src="/gallery/<?php echo $res_image_name; ?>" class="img_thumb" /></a>
				</div>
		
			<?php
					$count++;
				}
			}
			else
			{
				echo "<center>No Search Result Found</center>";
			}
			
			}
			else if($search_criteria=="image_based_search")
			{
				echo $value_name	=	$_FILES['photoimg']['tmp_name'];;
			/*	include_once __DIR__.'/GoogleImageSearch.php';
				
				$imageSearch = new GoogleImageSearch();
				
				$value_name = "";
				
				//$value_name	=	$_FILES['photoimg']['tmp_name'];
				
				if($value_name!="")
				{
					if($results = $imageSearch->search($value_name, 2)) {
						if($results['search_results']) {
							echo "Best guess: <strong><a href=\"{$results['best_guess'][1]}\">{$results['best_guess'][0]}</strong><br />\n";
							echo "<ol><br />\n";
							foreach($results['search_results'] as $k => $r) {
								echo "<li><a href=\"{$r[1]}\">{$r[0]}</a> ; <a href=\"{$r[2]}\">Original image</a></li>\n";
							}
							echo "</ol><br />\n";
						} else {
							echo 'Nothing found';
						}

					}
				}
				else
				{
					echo "Please select file";
				}*/
			}
		?>
	</div>

	<?php
		require_once('footer.php');
	?>
</body>
</html>